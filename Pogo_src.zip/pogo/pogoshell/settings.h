
uint32 set_getvalues(void);
void set_setvalues(uint32 v);
void init_settings(void);

#define NUM_SETTINGS 9

enum {SET_EXT, SET_2D, SET_FIXED, SET_SAVE, SET_LOAD, SET_MAPSRAM, SET_MAPSET, SET_HIDE, SET_SRAMPREV};
#define SF_EXT 1
#define SF_LAYOUT 2
#define SF_FIXED 4
#define SF_SAVE 8
#define SF_LOAD 16
#define SF_MAPSRAM 32
#define SF_MAPSET 64
#define SF_HIDE 128
#define SF_SRAMPREV 256
