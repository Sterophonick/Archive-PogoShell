/*
 * PooShell sourcecode (gui.c) - created by Jonas Minnberg 2002
 *
 * User interface code
 *
 ****/

#include "pogo.h"
#include "gui.h"

#include "text.h"

#define VRAM ((uchar *)0x06000000)
Font *gui_font = NULL;
Font *fixed_font = NULL;

int tb_height;// = 12;
int sb_height;// = 0;
int wb_height;// = 13;
int icon_w;// = 16;
int icon_h;// = 15;
int num_icons;// = 13;
char ifile[32];

int bgcolor;// = 15;
int fgcolor;

Icon *title_bar;// = NULL;
Icon *status_bar;// = NULL;
Icon *window_bar;// = NULL;

Icon **icons;

void block_set(uchar *dest, int width, int height, int dwidth, uint16 v);

int scaler = 0x100;
//int width2 = 0;

inline void blit(uchar *dest, uchar *src, int width, int height, int swidth, int dwidth)
{
	uint16 wrd;
	register uint16 *d;
	register uchar *p = (uchar *)&wrd;
	register int w;
	register int odd = 0;
	int spos = 0;
	int dmod;

	if((int)dest&1)
	{
		width--;
		odd = 1;
		dest = (uchar *)((int)dest & 0xFFFFFFFE);
		dwidth--;
	}
	if(width&1)
	{
		width--;
		odd += 2;
	}
	width = width>>1;
	dmod = (dwidth>>1)-width;
	d = (uint16 *)dest;
	//if(width2)
	//	width = width2;
	while(height--)
	{
		w = width;
		if(odd&1)
		{
			w = width;
			wrd = *d;
			p[1] = src[spos>>8];
			spos+=scaler;
			*d++ = wrd;
		}
		while(w--)
		{
			wrd = *d;
			p[0] = src[spos>>8];
			spos += scaler;
			p[1] = src[spos>>8];
			spos += scaler;
			*d++ = wrd;
		}
		if(odd&2)
		{
			wrd = *d;
			p[0] = src[spos>>8];
			spos+=scaler;
			*d = wrd;
		}
		d += dmod;
		src += swidth;
		spos = 0;
	}
	return;
}

inline void scaled_blit(uchar *dest, uchar *src, int width, int sc_width, int height, int swidth, int dwidth)
{
	scaler = (width<<8)/sc_width;
	//width2 = sc_width/2;
	blit(dest, src, sc_width, height, swidth, dwidth);
	scaler = 0x100;
	//width2 = 0;
}

void gui_readicons(char *name, char *cfgname)
{
	int i,c;
	uchar *buf, *ptr;
	uchar colors[3*256];
	uint32 start, size, width, height;
	int fd = open(name, 0);

	if(icons)
		free(icons);

	icons = malloc(sizeof(Icon*) * num_icons);

	for(i=0; i<num_icons; i++)
		icons[i] = malloc(icon_w*icon_h + 2);

	if(fd >= 0) {
		int sfd = open("/dev/screen", 0);
		lseek(fd, 10, SEEK_SET);
		read(fd, &start, 4);
		read(fd, &size, 4);
		read(fd, &width, 4);
		read(fd, &height, 4);
		//read(fd, &bpp, 2);
		//read(fd, &bpp, 2);
		//fprintf(stderr, "bmp %d bpp\n", bpp);
		//if(bpp == 8)
		//{
			lseek(fd, size+14, SEEK_SET);
			for(i=0; i<256; i++) {
				read(fd, &colors[i*3], 3);
				c = colors[i*3];
				colors[i*3] = colors[i*3+2];
				colors[i*3+2] = c;
				lseek(fd, 1, SEEK_CUR);
			}
			ioctl(sfd, SC_SETPAL, colors, 16, 240);
		//}
		lseek(fd, start, SEEK_SET);

		if(tb_height)
			title_bar = malloc(240*tb_height +  2);

		if(sb_height)
			status_bar = malloc(240*sb_height +  2);

		if(wb_height)
			window_bar = malloc(240*wb_height +  2);

		buf = malloc(width*height);
		for(i=(height-1); i>=0; i--)
			read(fd, &buf[width*i], width);
		for(i=0; i<width*height; i++)
			buf[i] += 16;
		close(fd);
	
		ptr = &buf[(tb_height+sb_height+wb_height)*width];
		for(i=0; i<num_icons; i++)
		{
			icons[i]->w = icon_w;
			icons[i]->h = icon_h;
			blit(icons[i]->pixels, ptr, icon_w, icon_h, width, icon_w);
			ptr += icon_w;
		}
		i = 0;
		if(tb_height)
		{
			title_bar->w = 240;
			title_bar->h = tb_height;
			blit(title_bar->pixels, buf, width, tb_height, width, 240);
			i += tb_height;
		}
		if(sb_height)
		{
			status_bar->w = 240;
			status_bar->h = sb_height;
			blit(status_bar->pixels, &buf[width*i], width, tb_height, width, 240);
			i += sb_height;
		}
		if(wb_height)
		{
			window_bar->w = 240;
			window_bar->h = wb_height;
			blit(window_bar->pixels, &buf[width*i], width, wb_height, width, 240);
		}

		free(buf);
	}

	if(!window_bar)
		window_bar = title_bar;
}

void gui_cfg(char *fname)
{
	int i;
	char buf[80];
	char *p;
	Font *f;
	FILE *fp = fopen(fname, "rb");
	strcpy(ifile, ".shell/icons.bmp");
	if(fp)
	{
		while(fgets(buf, sizeof(buf), fp))
		{
			i = strlen(buf)-1;
			while(buf[i] == 10 || buf[i] == 13) buf[i--] = 0;
			p = strchr(buf, '=');
			if(p)
			{
				*p++ = 0;
				//_dprintf("%s-%s\n", buf, p);
				if(strcmp(buf, "tb_height") == 0)
					tb_height = atoi(p);
				else
				if(strcmp(buf, "sb_height") == 0)
					sb_height = atoi(p);
				else
				if(strcmp(buf, "bgcolor") == 0)
					bgcolor = atoi(p);
				else
				if(strcmp(buf, "fgcolor") == 0)
					fgcolor = atoi(p);
				else
				if(strcmp(buf, "wb_height") == 0)
					wb_height = atoi(p);
				else
				if(strcmp(buf, "icon_width") == 0)
					icon_w = atoi(p);
				else
				if(strcmp(buf, "icon_height") == 0)
					icon_h = atoi(p);
				else
				if(strcmp(buf, "num_icons") == 0)
					num_icons = atoi(p);
				else
				if(strcmp(buf, "font") == 0)
				{
					if((f = font_load(p)))
					{
						//if(gui_font)
						//	free(gui_font);
						gui_font = f;
					}
				}
				else
				if(strcmp(buf, "fixed") == 0)
				{
					if((f = font_load(p)))
					{
						//if(fixed_font)
						//	free(fixed_font);
						fixed_font = f;
					}
				}
				else
				if(strcmp(buf, "icons") == 0)
					strcpy(ifile, p);
			}
		}
	}
	//_dprintf("'%s'\n", ifile);
	gui_readicons(ifile, NULL);
	if(!gui_font)
		gui_font = font_load(".shell/nokia.font");
	if(!fixed_font)
		fixed_font = font_load(".shell/fixed.font");
}

void gui_rendericon(Font *font, Icon *icon, char *text, int x, int y, int flags)
{
	int ih = 0;
	int iw = 0;
	uchar *ptr = VRAM+x+240*y;

	if(icon)
	{
		ih = icon->h;
		iw = icon->w;
		y = ((ih - font->height)/2)*240 + 4;
	}
	else
		y = 0;
	
	if(icon)
		blit(ptr, icon->pixels, iw, ih, iw, 240);
	if(text)
	{
		int l = font_text(font, text, NULL, 240);
		if(flags & INVERSE)
			font_setcolor(bgcolor, fgcolor);
		if(flags & ALIGN_RIGHT)
		{
			font_text(font, text, ptr + iw + y, 240);
		}
		else
		if(flags & ALIGN_UNDER)
		{
			font_text(font, text, ptr + (ih+1)*240 - l/2 + iw/2, 240);
		}
		else
		{
			font->flags |= FFLG_TRANSP;
			font_text(gui_font, text, ptr + y, 240);
			font->flags &= ~FFLG_TRANSP;
		}
		if(flags & INVERSE)
			font_setcolor(fgcolor, bgcolor);
	}
}

void gui_setfont(Font *f)
{
	if(gui_font)
		free(gui_font);
	gui_font = f;
}

int gui_messagebox(Icon *icon, char *title, char *text, int timeout)
{
	int c = -1;
	char tmp[240];
	char *tptrs[12];
	int lens[12];
	int maxl;
	uchar *p, *ptr;
	int x,y,i, ic = 0;
	int width = 200;
	int height = 120;
	int tw = font_text(gui_font, title, NULL, 240);
	int fh = gui_font->height;

	timeout *= 5;
	if(!timeout)
		timeout = 999999999;

	strcpy(tmp, text);
	tptrs[0] = p = tmp;
	ic = 1;
	maxl = 0;
	while((p = strchr(p, 10)))
	{
		*p = 0;
		tptrs[ic] = ++p;
		lens[ic-1] = font_text(gui_font, tptrs[ic-1], NULL, 240);
		if(lens[ic-1] > maxl)
			maxl = lens[ic-1];
		ic++;
	}
	lens[ic-1] = font_text(gui_font, tptrs[ic-1], NULL, 240);
	if(lens[ic-1] > maxl)
		maxl = lens[ic-1];

	width = maxl+8;
	height = (ic+1)*fh+title_bar->h;

	x = 120-(width/2);
	y = 80-(height/2);

	ptr = &VRAM[y*240 + x];
	font_setcolor(0, 7);
	block_set(ptr, width, height, 240, 7);
	//block_set(ptr, width, fh+4, 240, 6);
	scaled_blit(ptr, window_bar->pixels, window_bar->w, width, window_bar->h, window_bar->w, 240);
	gui_font->flags |= FFLG_TRANSP;
	font_text(gui_font, title, ptr+((title_bar->h/2-fh/2)*240)+width/2-tw/2, 240);
	gui_font->flags &= ~FFLG_TRANSP;

	ptr += (height/2-(ic * fh)/2+title_bar->h/2)*240;

	for(i=0; i < ic; i++)
	{
		font_text(gui_font, tptrs[i], ptr+width/2-lens[i]/2, 240);
		ptr += fh*240;
	}
	font_setcolor(fgcolor, bgcolor);
	
	{
		int t = clock();
		while((((c = getchar()) == EOF) || (c&0x80)) && (clock() < (t+timeout)));
	}
	return c;
}

int gui_yesno(char *question)
{
	int rc;
	char tmp[128];
	sprintf(tmp, TEXT(YES_NO), question);
	while(1)
	{
		rc = gui_messagebox(NULL, TEXT(QUESTION), tmp, 0);
		if(rc == RAWKEY_A)
			return 1;
		else
		if(rc == RAWKEY_B)
			return 0;
	}
}
