/* Standard core_init() for pogo programs
 * -- Jonas Minnberg 2002
 */

#include "device.h"
#include "font.h"

void set_ram_start(int i);

extern void deb_init(void); /* /dev/deb */
extern void screen_init(void); /* /dev/screen */
extern void vkey_init(void); /* /dev/vkey */
extern void key_init(void); /* /dev/key */
extern void console_init(void); /* /dev/con */
extern void filesys_init(void); /* /rom */
extern void sram_init(void); /* /sram */

void core_init(void)
{
	/* Only init devices we need */
	filesys_init();

//	deb_init();
	screen_init();
//	vkey_init();
	key_init();

	set_ram_start(1);

	sram_init();
#ifndef MINIMAL
	console_init();
	/* Set console fonts */
#endif

}
