/*
 * PooShell sourcecode (main.c) - created by Jonas Minnberg 2002
 *
 * Main code
 *
 ****/

#define VERSION "1.0"

#include "pogo.h"
#include "rle.h"
#include "gui.h"
#include "text.h"
#include "settings.h"

/* Include support for sram & settings as mountpoints in the filesystem */
#define S_FS

/* Include the Easter Egg */
#define GURU



#ifdef GURU

/* Well guess :) */
uchar guru_text[] = {
0x53,0x1c,0xf7,0x0e,0x03,0xea,0x11,0xf3,0xbb,0x26,0x1b,0x08,0x03,0x09,0xfd,0xf3,
0xc9,0xf2,0x30,0x22,0xf3,0x0e,0x00,0xad,0x21,0xdf,0x42,0x13,0xff,0x00,0xfb,0xff,
0xb2,0x54,0xfb,0xb1,0x43,0x0c,0xff,0x06,0xf5,0x05,0x07,0xf0,0xa8,0xfd,0x3d,0x2e,
0xfd,0x03,0xab,0x2d,0x18,0xff,0x05,0x0b,0xed,0x13,0xf5,0x06,0xff,0xb2,0x03,0x0d,
0x00,0x00,0x00,0x00,0x00,0x00,0x04,0xfa,0x02,0x00,0x00,0x00,0x11,0x00,0x02,0xed,
};

#endif

/* Translatable text strings loaded from .shell/texts */
char *text_strings[TEXT_END];

/* Settings flags */

typedef struct
{
	char name[36];
	unsigned int size;
	unsigned int type;
}  __attribute__ ((packed)) DirList;

typedef struct
{
	char ext[8];
	Icon *icon;
	int (*handler)(char *name);
	char *cmd;
	char *txt;
} __attribute__ ((packed)) FileType;

/* libpogo functions that are not defined in the headers */
void execv_mb(const char *cmdname, const char *const *argv);
void execv_jump(const char *cmdname, const char *const *argv, void *jump);
int free_space(void);
void block_set(uchar *dest, int width, int height, int dwidth, uint16 v);

void filesys_next();
void set_ram_start(int i);
void sram_init(void);
void Reset(void);
void Halt(void);

void status(char *s);

static void *jump;

#define VRAM ((uchar *)0x06000000)


/* Defines from gui.c (I need a cleaner abstraction between gui and main, really! :) */
extern Font *gui_font;
extern Font *fixed_font;

extern Icon *title_bar;
extern Icon *status_bar;
extern Icon *window_bar;
extern Icon **icons;

extern int bgcolor;
extern int fgcolor;

Icon *set_icon = NULL;

int ftcount;
FileType *ftlist[32];
DirList dirlist[64];
DirList *sorted[64];

#ifdef S_FS

const DirList setdir = { "settings", 40, 3 };
const DirList sramdir = { "sram", 40, 2 };

#endif

/* The working modes */
enum {MODE_FVIEW, MODE_SRAM, MODE_SETTINGS};
int mode;

/* Current bank for SRAM filesystem */
int current_bank = 1;

/* Current and previous directory (and file) */
char current[100];
char prev[100];

/* Current clipboard contents */
uchar *clipboard = NULL;
int clipsize = 0;
char clipname[40];

/* State, saved to  /sram/.state */
struct {
	unsigned int settings;
	signed char dirstart;
	signed char marked;
}  __attribute__ ((packed)) state;



/* Hmm.... releasing source really spoils easter-eggs :9 */

#define BG_PALRAM ((uint16*)0x05000000)
#define VCOUNT  (*(volatile unsigned short*)0x04000006)
#define KEYS  (*(volatile unsigned short*)0x04000130)

#ifdef GURU
void guru(void)
{
	int i = 0;
	int l, k = 25;
	char *p, *q;
	uint32 *ptr = (uint32*)VRAM;
	l = 1;
	while(l)
		l = (~KEYS) & 0x3FF;

	BG_PALRAM[1] = 0x1F;
	BG_PALRAM[2] = 0x1F;

	l = 60*3;
	while(l--)
		*ptr++ = 0x01010101;

	while(k--)
	{
		*ptr++ = 0x00010101;
		l = 58;
		while(l--)
			*ptr++ = 0;
		*ptr++ = 0x01010100;
	}
	l = 60*3;
	while(l--)
		*ptr++ = 0x01010101;
	l = 60*129;
	while(l--)
		*ptr++ = 0;

	font_setcolor(2, 0);
	ptr = (uint32 *)&VRAM[60*20+8];
	p = guru_text;
	q = current;
	k = 0;
	for(i=0; i<sizeof(guru_text); i++)
	{
		k += *p++;
		*q++ = k;
	}
	*q = 0;
	p = current;
	q = &current[0x2C];
	*q = 0;
	q += 2;
	
	font_text(fixed_font, p, (uchar *)ptr, 240);
	ptr += 60*12+6;
	font_text(fixed_font, q, (uchar *)ptr, 240);
	l = i = 0;
	while(1)
	{
		l++;
		while(VCOUNT != 170);
		while(VCOUNT == 170);
		if(!(l&0x1F))
		{
			i ^= 0x001F;
			BG_PALRAM[1] = i;
		}

		k = ~KEYS;
		if(k & 1)			Reset();
	}
}

#endif

/* Build a savefile name from a romname */
void make_savename(char *in, char *out)
{
	char *ptr = strrchr(in, '/');
	if(!ptr)
		ptr = in;
	else
		ptr++;

	sprintf(out, "/sram/%s", ptr);
	if(strlen(out) > 38)
		out[38] = 0;

	ptr = strrchr(out, '.');
	if(ptr)
		*ptr = 0;
	strcat(out, ".sav");
}

/* Save current state to SRAM */
void save_state(void)
{
	int fd;
	set_ram_start(1);
	sram_init();

	state.settings = set_getvalues();

	fd = open("/sram/.state", O_CREAT);
	if(fd >= 0)
	{
		write(fd, &state, sizeof(state));
		write(fd, current, strlen(current)+1);
		close(fd);
	}
	set_ram_start(current_bank);
	sram_init();

}

/* Load current state from SRAM */
int load_state(void)
{
	int fd;
	set_ram_start(1);
	sram_init();
	fd = open("/sram/.state", 0);
	if(fd >= 0)
	{
		read(fd, &state, sizeof(state));
		read(fd, current, 100);
		close(fd);
		set_setvalues(state.settings);
		set_ram_start(current_bank);
		sram_init();
		return 1;
	}
	set_ram_start(current_bank);
	sram_init();
	return 0;
}








/* -------------------------- INTERNAL FILE HANDLERS -------------------------- */

#ifndef MINIMAL

/* Textreader */

static int x;
static int line;
static int dotext;

#define BUF_SIZE 80
static char buffer[BUF_SIZE+2];

static void next_line(void)
{
	int c;
	putchar(10);
	line++;
	x = 0;
	if(line == 19)
	{
		printf("[MORE]");
		line = 0;
//		Halt();
		while((c = getchar()) > 10 || c < 0);
		if(c == RAWKEY_B)
			dotext = 0;
		printf("%c", 250);
	}
}

static void textflush(void)
{
	char *ptr, *wptr, *eptr;
	char word[128];
	int l;

	//*bufptr = 0;
	ptr = buffer;
	eptr = &word[126];
	while(*ptr && dotext)
	{
		while(*ptr == 10)
		{
			//fprintf(2, "line\n");
			next_line();
			ptr++;
		}
		while(*ptr == 13)
			ptr++;

		wptr = word;
		while(wptr < eptr && *ptr && *ptr != 10 && *ptr != 13 && *ptr != ' ')
			*wptr++ = *ptr++;
		while(wptr < eptr && *ptr && *ptr == ' ')
			*wptr++ = *ptr++;
		*wptr = 0;
		if(*word)
			l = ioctl(1, CC_GETWIDTH, word);
		else
			l = 0;
		if(l + x > 240)
		{
			if(l+x > 244)
				next_line();
			else 
				wptr[-1] = 0;
		}
		x += l;
		printf(word);
	}
	//bufptr = buffer;
}

int show_text(char *name)
{
	int rc;
	FILE *fp;
	x = line = 0;
	if(state.settings & SF_FIXED)
		printf("\033[30;55m\0331f");
	else
		printf("\033[30;55m\0330f");
	putchar(12);
	//printf("\0331f");
	ioctl(1, IO_SETMODE, CM_LINEWRAP);
	dotext = 1;

	if((fp = fopen(name, "rb")))
	{
		while((rc = fread(buffer, 1, 80, fp)) && dotext)
		{
			//_dprintf("rc=%d\n", rc);
			buffer[rc] = 0;
			//bufptr = &buffer[rc];
			textflush();
		}
		printf("\n[EOF]");
		line = 0;
		if(dotext)
			while(getchar() != RAWKEY_A);
		ioctl(1, IO_SETMODE, 0);
//		printf("\0330f");
		putchar(12);
		fclose(fp);
	}
	return 1;
}

#endif

/* Rom (GBA/BIN) executor */

int execute_rom(char *current)
{
	int found = 0;
	int i,fd, rc = 1;
	char tmp[40];
	char tmp2[64];
	char id[8];
	const char *args[2];
	char *p;
	args[0] = NULL;

	/* Get ID from rom to execute */
	strcpy(tmp2, "SAVE");
	fd = open(current, 0);
	p = (char *)lseek(fd, 0, SEEK_MEM);
	/* Get 2byte ID and complement (checksum) */
	tmp2[5] = p[0xAD];
	tmp2[6] = p[0xAE];
	tmp2[7] = p[0xBD];
	close(fd);

	/* Default savefile name */
	make_savename(current, tmp);
	fd = open(tmp, 0);

	if(fd < 0)
	{
		struct dirent *de;
		DIR *d;

		/* Check all files in SRAM for a matching savefile */
		d = opendir("/sram");
		if(d)
		{
			p = strrchr(tmp, '/');
			p++;
			while(!found && (de = readdir(d)))
			{
				sprintf(p, "%s", de->d_name);
				fd = open(tmp, 0);
				if(fd >= 0)
				{
					read(fd, id, 8);
					//_dprintf("Checking %s = %c%c %d\n", de->d_name, id[5], id[6], id[7]);
					if(memcmp(id, tmp2, 8) == 0)
					{
						found = 1;
						close(fd);
					}
				}
			}
			closedir(d);
		}
	} else
	{
		close(fd);
		found = 1;
	}

	/* Save the last_exec file with info on the savefile */
	set_ram_start(1);
	sram_init();
	remove("/sram/last_exec"); /* Just to make sure */
	fd = open("/sram/last_exec", O_CREAT);
	if(fd >= 0)
	{
		if(!found)
			make_savename(current, tmp);
		write(fd, &current_bank, 1);
		write(fd, tmp2+5, 3);
		write(fd, tmp, strlen(tmp)+1);
		close(fd);
	}

	/* Ask if we should load the file we found */
	if(found && (state.settings & SF_LOAD))
	{
		sprintf(tmp2, TEXT(WISH_LOAD), tmp);
		rc = gui_yesno(tmp2);
	}

	/* Clear bank 0 */
	set_ram_start(0);
	p = (char *)0x0E000000;
	i = 64*1024;
	while(i--)
		*p++ = 0;

	/* Load the save file */
	if(found && rc)
	{
		set_ram_start(current_bank);
		sram_init();
		fd = open(tmp, 0);
		read(fd, tmp2, 8);
		if(!(tmp2[0] == 'S' && tmp2[1] == 'A' && tmp2[2] == 'V' && tmp2[3] == 'E'))
			lseek(fd, 0, SEEK_SET);
		load_rle(fd, 0);
		close(fd);
	}

	/* Set bank 0 and execute! */
	set_ram_start(0);
	execv_jump(current, args, jump);
	return 1;
}

/* Set a new font */
int set_font(char *current)
{
	Font *font = font_load(current);
	if(font)
		gui_setfont(font);
	status(TEXT(NEW_FONT));
	return 1;
}

/* Execute a Multiboot file */
int execute_mb(char *c)
{
	set_ram_start(1);
	execv_mb(c, NULL);
	return 1;
}






/* SRAM FUNCTIONS */



/* Copy a file to clipboard */
static int sram_copy(char *name)
{
	int l;
	int fd = open(name, 0);
	if(fd >= 0)
	{
		l = lseek(fd, 0, SEEK_END);
		lseek(fd, 0, SEEK_SET);
		if(l >= 0)
		{
			strcpy(clipname, name);
			read(fd, clipboard, l);
			clipsize = l;
			close(fd);
			return 0;
		}
	}
	return -1;
}

/* Cut a file to clipboard */
/*static int sram_cut(char *name)
{
	if(sram_copy(name) == 0)
	{
		return remove(name);
	}
	return -1;
}*/

/* Delete a file */
int sram_del(char *name)
{
	return remove(name);
}

/* Paste a file from clipboard */
int sram_paste(char *name)
{
	int fd;
	if(!clipsize)
		return -3;
	if(!name)
		name = clipname;

	if(free_space() > clipsize+8)
	{
		fd = open(name, 0);
		if(fd >= 0)
		{
			close(fd);
			return -1;
		}
		fd = open(name, O_CREAT);
		if(fd >= 0)
		{
			write(fd, clipboard, clipsize);
			close(fd);
			return 0;
		}
		return -4;
	}
	return -2;
}


static FileType deftype;

/* Read the filetypes file and set up connections between file extentions
   and icons + handlers
*/
void init_filetypes(char *fname)
{
	char buf[80];
	int i;
	FileType *f;
	char *p, *ptr;
	FILE *fp = fopen(fname, "rb");

	*(deftype.ext) = 0;
	deftype.cmd = "";
	deftype.handler = NULL;

	if(fp)
	{
		fgets(buf, sizeof(buf), fp);
		i = atoi(buf);
		deftype.icon = icons[i];

		/* Every line is one filetype */
		while(fgets(buf, sizeof(buf), fp))
		{
			f = ftlist[ftcount++] = malloc(sizeof(FileType));
			ptr = buf;
			while(*ptr++ != ' ');

			f->txt = NULL;

			ptr[-1] = 0;

			/* First word is the extention */
			strcpy(f->ext, buf);

			/* Second word is the icon number */
			i = atoi(ptr);
			f->icon = icons[i];
			
			while(isdigit(*ptr++));
			p = ptr;

			/* Third word is the handler */
			while((*ptr != ' ') && (*ptr != 10) && (*ptr != 13)) ptr++;
			if(*ptr == ' ')
			{
				char *q = ptr+1;

				/* The rest of the line is the description, if it exists */
				while((*q != 10) && (*q != 13)) q++;
				*q = 0;
				f->txt = malloc(strlen(ptr+1)+1);
				strcpy(f->txt, ptr+1);
			}
			*ptr = 0;
			/* Set correct internal handler for filetype */
			if(strcmp(p, "EXE") == 0)
				f->handler = execute_rom;
			else
#ifndef MINIMAL
			if(strcmp(p, "TXT") == 0)
				f->handler = show_text;
			else
#endif
			if(strcmp(p, "MB") == 0)
				f->handler = execute_mb;
			else
			if(strcmp(p, "FNT") == 0)
				f->handler = set_font;
			else
			if(strcmp(p, "SET") == 0)
			{
				set_icon = f->icon;
			}
			else
			{
				/* No internal filetype found so assume handler is an actual rom that will be
				   executed for files with this extention */
				f->handler = NULL;
				f->cmd = malloc(strlen(p)+1);
				strcpy(f->cmd, p);
			}
		}
		fclose(fp);
	}
}

static FileType settype;
FileType *get_settingtype(char *name)
{
	settype.icon = set_icon;
	return &settype;
}

FileType temp_type;

/* Get the filetype for a given file (type != 1 means directory) */
FileType *get_filetype(char *name, int type)
{
	char tmp[200];
	int i = 0,fd;
	Icon *found_icon = NULL;
	char *p;

	if((p = strrchr(name, '.')))
		i = 1;
	else
		p = &name[strlen(name)];

	//_dprintf("'%s' -> '%s'\n", name, p);

	if(type < 10 && strcmp(p, "icon") != 0)
	{
		sprintf(tmp, "%s/.%s", current, name);
		strcpy(&tmp[p-name+strlen(current)+2], ".icon");
		fd = open(tmp, 0);
		//_dprintf("Looking for %s\n", tmp);
		if(fd >= 0)
		{
			//_dprintf("Found icon %s\n", tmp);
			found_icon = (Icon *)lseek(fd, 0, SEEK_MEM);
			close(fd);
		}
	}

	if(i)
	{
		p++;
		for(i=0; i<ftcount; i++)
		{
			if(strcmp(p, ftlist[i]->ext) == 0)
			{
				memcpy(&temp_type, ftlist[i], sizeof(FileType));
				if(found_icon)
					temp_type.icon = found_icon;
				return &temp_type;
			}
		}
	}

	memcpy(&temp_type, &deftype, sizeof(FileType));
	if(found_icon)
		temp_type.icon = found_icon;
	else
	if(type)
		temp_type.icon = icons[0];
	return &temp_type;
}

/* Read all files and directories inside a directory into a dirlist */
int get_dir(char *name, DirList *list)
{
	int i;
	char *p;
	DIR *dir;
	struct dirent *de;
	struct stat sbuf;
	DirList *dl;

	i = 0;
	dir = opendir(name);
	if(dir)
	{
		for(i=0; ((de = readdir(dir)) && i<256); i++)
		{
			dl = &list[i];
			strcpy(dl->name, de->d_name);
			p = &name[strlen(name)];
			*p = '/';
			strcpy(p+1, de->d_name);
			stat(name, &sbuf);
			dl->size = sbuf.st_size;
			*p = 0;
			if((state.settings & SF_HIDE) && de->d_name[0] == '.')
				i--;
			else
			{
				if(sbuf.st_mode & S_IFDIR)
					dl->type = 1;
				else
					dl->type = 0;
			}
		}
		closedir(dir);
	}
	return i;
}

/* Sort dirlist into directories and files */
void sort_dir(DirList *list, int n, DirList** dest)
{
	int i,j = 0;
	for(i=0; i<n; i++)
	{
		if(list[i].type)
		{
			dest[j++] = &list[i];
		}
	}
	for(i=0; i<n; i++)
	{
		if(!(list[i].type))
		{
			dest[j++] = &list[i];
		}
	}
}

char status_text[80]; // = "Ready.";

/* Set the string of the statusbar */
void status(char *s)
{
	if(s)
		strcpy(status_text, s);
	if(status_bar)
		gui_rendericon(gui_font, status_bar, status_text, 0, 148, 0);
}

int size_w,off;

/* Render a dirlst as a list */
void render_list(DirList **sorted, int count, int dirstart, int max_disp, int marked)
{
	int i;
	FileType *ftype;
	char *p;
	char tmp[128];
	int l,max = 240-size_w-icons[0]->w-8;
	int y = off;
	/* Render list */

	for(i=0; i<count; i++)
	{
		if((i >= dirstart) && (i <= dirstart+(max_disp-1))) 
		{
			DirList *dl = sorted[i];
			if(mode == MODE_SETTINGS)
				ftype = get_settingtype(dl->name);
			else
				ftype = get_filetype(dl->name, dl->type);
			strcpy(tmp, dl->name);
			if((state.settings & SF_EXT) && ftype->ext[0])
			{
				char *q = strrchr(tmp, '.');
				if(q)
					*q = 0;
			}
			p = &tmp[strlen(tmp)];
			while((l = font_text(gui_font, tmp, NULL, 240)) > max)
			{
				--p;
				strcpy(p, "...");
			}

			gui_rendericon(gui_font, ftype->icon, tmp, 0, y, 1 | ((marked == i) ? 2 : 0));
			if(mode == MODE_SETTINGS)
			{
				font_text(gui_font, dl->size ? TEXT(YES) : TEXT(NO), &VRAM[(y+2)*240+(240-24)], 240);
			}
			else
			{
				if(!(dl->type) && (size_w < 80))
				{
					sprintf(tmp, "%d", dl->size);
					font_text(gui_font, tmp, &VRAM[(y+2)*240+(240-size_w)], 240);
				}
			}
			if(!ftype->icon || (gui_font->height > ftype->icon->h))
				y += gui_font->height;
			else
				y += ftype->icon->h;
		}
	}
}

/* Render a dirlist as icons (2D layout) */
void render_icons(DirList **sorted, int count, int dirstart, int max_disp, int marked)
{
	int i,l;
	char *p;
	int ih = icons[0]->h;
	int iw = icons[0]->w;
	FileType *ftype;
	char tmp[256];
	int x = 40-iw/2;
	int y = off;

	/* Render list */
	for(i=0; i<count; i++)
	{
		if((i >= dirstart) && (i <= dirstart+(max_disp-1))) 
		{
			DirList *dl = sorted[i];
			if(mode == MODE_SETTINGS)
				ftype = get_settingtype(dl->name);
			else
				ftype = get_filetype(dl->name, dl->type);
			strcpy(tmp, dl->name);
			if((state.settings & SF_EXT) && ftype->ext[0])
			{
				char *q = strrchr(tmp, '.');
				if(q)
					*q = 0;
			}
			p = &tmp[strlen(tmp)];
			while((l = font_text(gui_font, tmp, NULL, 240)) > 76)
			{
				--p;
				strcpy(p, "...");
			}
			if(x > 240)
			{
				x = 40-iw/2;
				y += (ih + gui_font->height + 2);
			}

			gui_rendericon(gui_font, ftype->icon, tmp, x, y, ALIGN_UNDER | ((marked == i) ? 2 : 0));
			x += 80;
		}
	}
}


int main(int argc, char **argv)
{
	int modifiers = 0;
	char fromdir[40];
	int count, i, fd, l;
	int splash = 1;
	int tb,sb,ih;
	int max_disp;
	int c;
	char *p;
	FileType *ftype;
	FILE *fp;
	int done = 0;
	char tmp[256];
	char id[3];

	*clipname = *status_text = 0;

	/* Read the translatable texts */
	i = 0;
	fp = fopen(".shell/texts", "rb");
	if(fp)
	{
		while(fgets(tmp, 256, fp))
		{
			char *q = tmp;
			p = tmp;
			while(*p && (*p != 10) && (*p != 13))
			{
				if(*p == '\\')
				{
					if(p[1] == 'n')
					{
						*q++ = 10;

					}
					p += 2;
				}
				else
					*q++ = *p++;
			}
			*q = 0;
			l = strlen(tmp);
			//_dprintf("Got '%s' %d\n", tmp, l);
			text_strings[i] = malloc(l+1);
			strcpy(text_strings[i], tmp);
			i++;
		}
		fclose(fp);
	} else
	{
		/* Freeze if no texts are present */
		while(1);
	}

	init_settings();

	gui_cfg(".shell/gui.cfg");
	init_filetypes(".shell/filetypes");
	clipboard = malloc(65536);

#ifndef MINIMAL
	ioctl(1, CC_SETFONT, fixed_font, 1);
	ioctl(1, CC_SETFONT, gui_font, 0);
#endif

	font_setcolor(fgcolor, bgcolor);

	status(NULL);
	while(getchar() != EOF);

	block_set(VRAM, 240, 160, 240, bgcolor);

	strcpy(current, "");
	if(load_state())
		splash = 0;
	else
	{
		memset(&state, 0, sizeof(state));
	}

	/* See if we just executed a ROM and should save a savefile for it */
	fd = open("/sram/last_exec", 0);
	if(fd >= 0)
	{
		char tmp2[40];
		int rc = 1;
		current_bank = 0;
		read(fd, &current_bank, 1);
		read(fd, id, 3);
		read(fd, tmp2, 128);
		close(fd);

		/* Should we ask the user about saving? */
		if(state.settings & SF_SAVE)
		{
			uchar *ptr = (uchar *)0x0E00FFFF;
			set_ram_start(0);
			while(((uint32)ptr >= 0x0E000000) && (ptr[0] == 0)) ptr--;
			if(ptr - 0x0E000000 + 1 > 0)
			{
				sprintf(tmp, TEXT(WISH_SAVE), tmp2, current_bank);
				rc = gui_yesno(tmp);
				if(!rc)
					status(TEXT(SAVE_CANCEL));
			} else
				rc = 0;
		}

		if(rc)
		{
			/* We should save */
			set_ram_start(current_bank);
			sram_init();
			fd = open(tmp2, O_CREAT);
			write(fd, "SAVE", 5);
			write(fd, &id, 3);
			rc = save_rle(fd, 0, current_bank);
			close(fd);
			if(rc > 0)
			{
				set_ram_start(1);
				sram_init();
				remove("/sram/last_exec");
				sprintf(tmp, TEXT(SAVE_DONE), tmp2);
				status(tmp);
			} else
			if(rc == -1)
				status(TEXT(SAVE_SRAMFULL));
		}
		else
		{
			set_ram_start(1);
			sram_init();
			remove("/sram/last_exec");
		}
	}

	set_ram_start(current_bank);
	sram_init();

	/* Calculate some sizes/offsets depending on size of icons, titlebar and statusbar */
	tb = title_bar->h;
	if(status_bar)
		sb = status_bar->h;
	else
		sb = 0;
	ih = icons[0]->h;
	max_disp = (160-sb-tb)/ih;
	off = tb+((160-sb-tb)%ih)/2;
	size_w = font_text(gui_font, "0000000", NULL, 240);



	/******************************* Main loop **********************************/
	while(1)
	{
		int refresh = 1;
		while(!done)
		{
			if(mode == MODE_SETTINGS || (!(state.settings & SF_LAYOUT)))
			{
				/* Calculate sizes for list layout */
				if(mode == MODE_SETTINGS)
				{
					if(set_icon)
						ih = set_icon->h;
					else
						ih = 0;
				}

				if(gui_font->height > ih)
					ih = gui_font->height;
				max_disp = (160-sb-tb)/ih;
				off = tb+((160-sb-tb)%ih)/2;
			}
			else
			{
				/* Calculate sizes for 2D layout */
				max_disp = ((160-sb-tb)/(ih+gui_font->height+2))*3;
				off = tb+((160-sb-tb)%(ih+gui_font->height+2))/2;
			}

			if(refresh)
			{
				/* Redraw titlebar and statsubar and clear between */
				p = current;
				l = font_text(gui_font, p, NULL, 240);
				while(p && l > 145)
				{
					p = strchr(p, '/');
					if(p)
					{
						p++;
						l = font_text(gui_font, p, NULL, 240);
					}
				}
				if(!p)
					p = "<truncated>";

				if(mode == MODE_SRAM)
				{
					sprintf(tmp, "Pogoshell " VERSION " (/sram%d) %d bytes free", current_bank, free_space());
				}
				else
					sprintf(tmp, "Pogoshell " VERSION " (%s)", strlen(p) ? p : "/");
				/* Render titlebar */
				gui_rendericon(gui_font, title_bar, tmp, 0, 0, 0);


				/* Clear listarea */
				block_set(&VRAM[tb*240], 240, 160-(tb+sb), 240, bgcolor);
				status(NULL);
			}

			refresh = 0;
			count = get_dir(current, dirlist);
#ifdef S_FS
			if(!*current)
			{
				/* Add settings and or sram to root directory */
				if(state.settings & SF_MAPSET)
					dirlist[count++] = setdir;
				if(state.settings & SF_MAPSRAM)
					dirlist[count++] = sramdir;
			}
#endif
			sort_dir(dirlist, count, sorted);
			if(*fromdir)
			{
				/* Mark the folder we came from if we backed up */
				for(i=0; i<count; i++)
					if(strcmp(fromdir, sorted[i]->name) == 0)
						state.marked = i;
			}
			*fromdir = 0;

			/* Render list or icons */
			if((mode != MODE_SETTINGS) && (state.settings & SF_LAYOUT))
				render_icons(sorted, count, state.dirstart, max_disp, state.marked);
			else
				render_list(sorted, count, state.dirstart, max_disp, state.marked);

			if(splash)
			{
				sprintf(tmp, "PogoShell " VERSION " programmed by \nJonas Minnberg (Sasq / DCS).\nMail any suggestions and\nbug reports to: jonas@nightmode.org\nhttp://www.obsession.se/pocket/\n%s", TEXT(SELECT_HELP));
				gui_messagebox(NULL, "PogoShell " VERSION, tmp, 50);
				modifiers = 0;
				refresh = 1;
				splash = 0;
			}
			else
			{
				//Halt();
				while((c = getchar()) == EOF);

				/*** Handle keypresses ***/
				switch(c)
				{
				case RAWKEY_SELECT:
					if(modifiers == 1)
						splash = 1;
					else
					if(modifiers == 2)
					{
						if(!mode)
							strcpy(prev, current);
						state.dirstart = state.marked = 0;
						mode = MODE_SETTINGS;
						strcpy(current, "/settings");
					}
					else
					{
						if(mode == MODE_SRAM)
							gui_messagebox(NULL, TEXT(SRAM_HELP_TITLE), TEXT(SRAM_HELP_TEXT), 0);
						else
						if(mode == MODE_SETTINGS)
							gui_messagebox(NULL, TEXT(SETTINGS_HELP_TITLE), TEXT(SETTINGS_HELP_TEXT), 0);
						else
							gui_messagebox(NULL, TEXT(MAIN_HELP_TITLE), TEXT(MAIN_HELP_TEXT), 0);
						modifiers = 0;
					}
					refresh = 1;
					break;
				case RAWKEY_R|0x80:
					modifiers &= ~1;
					break;
				case RAWKEY_L|0x80:
					modifiers &= ~2;
					break;
				case RAWKEY_R:
					modifiers |= 1;
					break;
				case RAWKEY_L:
					modifiers |= 2;
					break;
				case RAWKEY_LEFT:
					state.marked--;
					break;
				case RAWKEY_RIGHT:
					state.marked++;
					break;
				case RAWKEY_UP:
					if(modifiers == 1)
						state.marked = 0;
					else
					if((mode != MODE_SETTINGS) && (state.settings & SF_LAYOUT))
						state.marked -= 3;
					else
						state.marked--;
					break;
				case RAWKEY_DOWN:
					if(modifiers == 1)
						state.marked = count-1;
					else
					if((mode != MODE_SETTINGS) && (state.settings & SF_LAYOUT))
						state.marked += 3;
					else
						state.marked++;
					break;
				case RAWKEY_A:
					if(mode == MODE_SETTINGS)
					{
						int l;
						int fd;
						sprintf(tmp, "/settings/%s", sorted[state.marked]->name);
						fd = open(tmp, 0);
						//_dprintf("open %s -> %d\n", tmp, fd);
						if(fd >= 0)
						{
							read(fd, &l, 4);
							l = l^1;
							write(fd, &l, 4);
							close(fd);
						}
					}
					else
					if(mode == MODE_SRAM)
					{
						int rc;
						char *s = sorted[state.marked]->name;
						sprintf(tmp, "/sram/%s", s);
						if(modifiers == 1)
						{
							rc = sram_copy(tmp);
							sprintf(tmp, TEXT(SRAM_COPY), s, rc);
							status(tmp);
						}
						else
						if(modifiers == 2)
						{
							rc = sram_paste(NULL);
							sprintf(tmp, TEXT(SRAM_PASTE), clipname, rc);
							status(tmp);
							refresh = 1;
						}
						else
						if(modifiers == 3)
						{
							rc = sram_del(tmp);
							sprintf(tmp, TEXT(SRAM_DEL), s, rc);
							status(tmp);
							refresh = 1;
						}
					}
					else
					{
						/* Execute or change directory */

						if(!(sorted[state.marked]->type))
							save_state();
						else
						if(sorted[state.marked]->type > 1)
							mode = sorted[state.marked]->type-1;
						strcat(current, "/");
						strcat(current, sorted[state.marked]->name);
						if(sorted[state.marked]->type )
						{
							//_dprintf("%s\n", current);
							refresh = 1;
							state.dirstart = state.marked = 0;
						}
						else
						{
							done = 1;
							if(modifiers == 1)
								jump = (void *)0x080000C0;
							else
							if(modifiers == 2)
								jump = (void *)0x0000008C;
						}
					}
					break;
				case RAWKEY_B:
					if((mode == MODE_SRAM || mode == MODE_SETTINGS) && (state.settings & SF_SRAMPREV))
					{
						refresh = 1;
						state.dirstart = state.marked = 0;
						mode = 0;
						strcpy(current, prev);
						state.settings = set_getvalues();
					}
					else
					{
						p = strrchr(current, '/');
						if(p)
						{
							strcpy(fromdir, p+1);
							*p = 0;
							refresh = 1;
							state.dirstart = state.marked = 0;
							mode = 0;
							state.settings = set_getvalues();
						}
					}
					break;
				case RAWKEY_START:
#ifdef GURU
					if((modifiers == 3) && (mode == MODE_SETTINGS) && ((state.settings & 0xFF) == 0xFF))
					//if(mode == MODE_SETTINGS)
					{
						guru();
					}
#endif
					if(modifiers == 1)
					{
						strcpy(current, "");
						refresh = 1;
						mode = 0;
					}
					else
					if(mode == MODE_SRAM)
					{
						if(++current_bank == 4) current_bank = 1;
						set_ram_start(current_bank);
						sram_init();
						refresh = 1;
						state.marked = 0;
					}
					else
					{
						if(!mode)
							strcpy(prev, current);
						strcpy(current, "/sram");
						mode = MODE_SRAM; //sram_mode ^ 1;
						refresh = 1;
						state.marked = 0;
						state.dirstart = 0;
						status(TEXT(SRAM_SWITCH));
					}
					break;
				}
			}

			
			if(state.marked >= count)
				state.marked = count-1;
			if(state.marked < 0)
				state.marked = 0;


			if((state.marked < state.dirstart) || (state.marked - state.dirstart >= max_disp))
			{
				state.dirstart = state.marked - max_disp/2;
				refresh = 1;
			}

			if(state.dirstart < 0)
				state.dirstart = 0;
		}

		/* Out of mainloop, time to execute */

		refresh = 1;
		modifiers = 0;

		ftype = get_filetype(current, 10);
		//_dprintf("%s %p\n", ftype->ext, ftype->handler);

		/* If this filetype has a handler, jump to it */
		if(ftype->handler)
			ftype->handler(current);
		else
		/* If it has a command then execute it */
		if(strlen(ftype->cmd))
		{
			char tmp[20];
			const char *args[2];
			args[0] = current;
			args[1] = NULL;
			fd = open(ftype->cmd, 0);
			if(fd >= 0)
			{	
				if(ftype->txt)
				{
					p = strrchr(current, '/');
					if(p)
						p++;
					else
						p = current;
					close(fd);
					sprintf(tmp, ftype->txt, p);
					status(tmp);
				}
				set_ram_start(0);
				execv(ftype->cmd, args);
			}
		}
		/* Otherwise, take the extention and look in the plugins folder */
		else
		{
			char tmp[20];
			const char *args[2];
			args[0] = current;
			args[1] = NULL;
			p = strrchr(current, '.');
			if(p)
			{
				sprintf(tmp, ".plugins/%s.bin", &p[1]);
				//_dprintf("Looking for %s\n", tmp);
				fd = open(tmp, 0);
				if(fd >= 0)
				{	
					close(fd);
					set_ram_start(0);
					execv(tmp, args);
				}
			}
		}

		/* Execution failed, back to mainloop */
		jump = 0;
		p = strrchr(current, '/');
		if(p)
			*p = 0;
		done = 0;
	}
}
