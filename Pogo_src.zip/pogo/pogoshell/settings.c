/*
 * PooShell sourcecode (settings.c) - created by Jonas Minnberg 2002
 *
 * Code for handling settings
 *
 ****/

#include "pogo.h"

#include "text.h"
#include "settings.h"

char *strings[NUM_SETTINGS];

int pos ;

static int values[NUM_SETTINGS];

uint32 set_getvalues(void)
{
	int i;
	uint32 v = 0;
	for(i=0; i<NUM_SETTINGS; i++)
		if(values[i])
			v |= (1<<i);
	return v;
}

void set_setvalues(uint32 v)
{
	int i;
	for(i=0; i<NUM_SETTINGS; i++)
		values[i] = (v & (1<<i)) ? 1 : 0;

}

int set_open(const char *name, int mode)
{
	int i;
	while(*name == '/')
		name++;
	if(!*name)
	{
		pos = 0;
		return 0;
	}

	for(i=0; i<NUM_SETTINGS; i++)
		if(strcmp(name, strings[i]) == 0)
		{
			return i+1;
		}
	return -1;
}

int set_close(int fd)
{
	return 0;
}

int set_stat(const char *name, struct stat *buffer)
{
	int i;
	while(*name == '/')
		name++;

	if(!*name)
	{
		buffer->st_size = NUM_SETTINGS*40;
		buffer->st_mode = S_IFDIR;
		return 0;
	}

	for(i=0; i<NUM_SETTINGS; i++)
		if(strcmp(name, strings[i]) == 0)
			break;

	if(i<NUM_SETTINGS)
	{
		buffer->st_size = values[i];
		buffer->st_mode = 0;
		return 0;
	}
	return -1;
}

int set_write(int fd, const void *src, int count)
{
	if(!fd)
		return -1;
	memcpy(&values[fd-1], src, 4);
	//_dprintf("Write value %d (%d)\n", values[fd-1], fd);
	return 4;
}

int set_read(int fd, void *dest, int count)
{
	Romfile rf;
	int org = count;
	//_dprintf("Read %d bytes from %d\n", count, fd);
	if(!fd)
	{
		if(pos >= NUM_SETTINGS)
			return 0;
		while(count >= sizeof(Romfile))
		{
			strcpy(rf.name, strings[pos++]);
			rf.start = rf.size = 0;

			memcpy(dest, &rf, sizeof(Romfile));
			dest += sizeof(Romfile);
			count -= sizeof(Romfile);
		}
		return org-count;
	}
	//_dprintf("Read value %d (%d)\n", values[fd-1], fd);
	memcpy(dest, &values[fd-1], 4);
	return 4;
}

Device setdev;

void init_settings(void)
{
	int i;
	memset(&setdev, 0, sizeof(Device));
	setdev.read = set_read;
	setdev.write = set_write;
	setdev.open = set_open;
	setdev.close = set_close;
	setdev.stat = set_stat;

	for(i=0; i<NUM_SETTINGS; i++)
	{
		values[i] = 0;
		strings[i] = TEXT(SETTINGS_START+i);
	}

	device_register(&setdev, "/settings", NULL, -1);
}
