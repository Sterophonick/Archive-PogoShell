typedef struct
{
	uchar w;
	uchar h;
	uchar pixels[0];
} __attribute__ ((packed)) Icon;

typedef struct
{
	Icon *icon;
	char *name;
	uint32 flags;
} IconList;

#define ALIGN_RIGHT 1
#define INVERSE 2
#define ALIGN_UNDER 4

void gui_rendericon(Font *font, Icon *icon, char *text, int x, int y, int flags);
void gui_setfont(Font *f);
int gui_yesno(char *question);
void gui_cfg(char *fname);
int gui_messagebox(Icon *icon, char *title, char *text, int timeout);


