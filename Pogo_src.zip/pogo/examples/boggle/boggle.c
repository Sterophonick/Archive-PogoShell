/* Mini boggle by Jonas Minnberg (jonas@nightmode.org)
 */

//#include <stdio.h>
//#include <stdlib.h>
//#include <string.h>
//#include <time.h>
#include "pogo.h"

static const char dice[6][6] ={"aeiouy", "aeioue", "tdbtgp", "rlhmnk", "cswfhs", "qxzjkv"};
static const int offs[] = {-9, -8, -7, -1, 1, 7, 8, 9, 0};
static char board[16*2+1];
static char visited[16*2];

void make_board(void)
{
	int used[] = {4,3,4,2,2,1,0};
	int i,dn=6;

	for(i=0; i<16; dn=6, i++)
	{
		while(!used[dn])
			dn = rand()%6;

		used[dn]--;
		board[i+(i&12)] = dice[dn][rand()%6];
		board[i+(i&12)+1] = 0;
	}
	board[32] = 0;
}

void print_board(void)
{
	int i;
	for(i=0; i<4; i++)
		printf("%s\n", &board[i*8]);
}

int check_board(char *w, int i)
{
	int *p, rc = 0;

	if(!w[1])
		return 1;

	visited[i] = 1;
	for(p = offs; !rc && *p; p++)
		if(!(i & 0x8204) && (w[1] == board[*p+i]) && !visited[*p+i])
			rc = check_board(w+1, *p+i);
	visited[i] = 0;

	return rc;
}

int check_word(char *word)
{
	int i;

	for(i=0; i<16*2; i++)
		visited[i] = 0;

	for(i=0;i<16; i++)
		if(board[i+(i&12)] == *word)
			if(check_board(word, i+(i&12)))
				return i;
	return -1;
}

int main(int argc, char **argv)
{
	int i;
	char input[80];
	srand(time(NULL));
	make_board();

	while(1)
	{
		print_board();
		gets(input);
		input[strlen(input)] = 0;
		if((i = check_word(input)) != -1)
			printf("Found at (%d,%d)\n", i%4+1, i/4+1);
		else
			printf("Not found\n");
	}
	return 0;
}
