#include "core.h"
#include "device.h"
#include "string.h"
#include "io.h"

void make_file(char *name, char *text)
{
	FILE *fp;
	int l = strlen(text);

	printf("Creating new file %s\n", name);
	if((fp = fopen(name, "wb")))
	{
		fprintf(stderr, "Writing to file %s\n", name);
		fwrite(text, l, 1, fp);
		fclose(fp);
	}
}

void print_file(char *name)
{
	int rc;
	FILE *fp;
	char text[200];

	printf("Reading file %s\n", name);
	if((fp = fopen(name, "r")))
	{
		rc = fread(text, 200, 1, fp);
		fprintf(stderr, "Read %d bytes\n", rc);
		text[rc] = 0;
		printf("%s\n", text);
		fclose(fp);
	}
}

int main(int argc, char **argv)
{
	int fd;
	uchar *ptr = 0x0E000000;

	ptr[128*1024 + 55] = 0x13;
	ptr[55] = 0x12;

	printf("%x %x\n", ptr[55], ptr[128*1024 + 55]);


	printf("\nTesting SRAM filesystem\n");
	printf("Free space = %d\n", free_space());

	fd = open("/sram/test1", 0);
	if(fd < 0)
		make_file("/sram/test1", "A testfile with some text");
	else
		close(fd);
	
	printf("Free space = %d\n", free_space());

	fd = open("/sram/test2", 0);
	if(fd < 0)
		make_file("/sram/test2", "Another testfile with more stupid text");
	else
		close(fd);

	printf("Free space = %d\n", free_space());

	print_file("/sram/test1");
	print_file("/sram/test2");


	remove("/sram/test2");

	printf("Free space = %d\n", free_space());

	while(1);

	return 0;
}
