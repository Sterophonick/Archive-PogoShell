#ifndef CONSOLE_H
#define CONSOLE_H

enum {CP_TEXWIDTH = 1, CP_WIDTH, CP_HEIGHT};

#endif
