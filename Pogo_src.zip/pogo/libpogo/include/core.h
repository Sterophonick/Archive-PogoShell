#ifndef CORE_H
#define CORE_H

typedef unsigned int uint32;
typedef int int32;
typedef unsigned short uint16;
typedef short int16;
typedef unsigned char uchar;

#ifndef NULL
#define NULL 0
#endif

#ifndef EOF
#define EOF (-1)
#endif

// Map stdargs to gcclibs implementation - should be in its own file
typedef __builtin_va_list va_list; 
#define va_start(v,l) __builtin_stdarg_start((v),l)
#define va_end __builtin_va_end
#define va_arg __builtin_va_arg


void *memset(void *dest, int v, int l);
void *memmove(void *dst, const void *src, int l);
void *memmove8(void *dst, const void *src, int l);
void *memcpy(void *dst, const void *src, int l);
void *memcpy8(void *dst, const void *src, int l);
int strcmp(const char *s1, const char *s2);
int strncmp(const char *s1, const char *s2, int n);
int strlen(const char *s);
char *strcpy(char *dst, const char *src);
char *strncpy(char *dst, const char *src, int n);
int memcmp(const char *s1, const char *s2, int n);

void memory_init(uint32 *ptr, int size);
void *memory_alloc(int size);
void memory_free(void *mem);

int clock(void);

#define memmove8 memmove

#define CLOCKS_PER_SEC 50

#ifdef MALLOC_DEBUG

#define malloc(x) (_dprintf("%s:%d %d bytes\n", __FILE__, __LINE__, x), memory_alloc(((x)+3)/4)) 
#define realloc(p, l)  (_dprintf("%s:%d %d bytes\n", __FILE__, __LINE__, x), memory_realloc(p, ((l)+3)/4)) 
#define free(p) memory_free(p)

#else

void *malloc(int x);
void *realloc(void *p, int l);
void free(void *x);

#endif

#endif
