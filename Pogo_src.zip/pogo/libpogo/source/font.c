/*
 * Font handling functions (font.c)
 * Part of libpogo, a c-library replacent for GBA
 * Programmed by Jonas Minnberg (Sasq)
 *
 * DESCRIPTION
 * Functions for writing text with different fonts into
 * an 8bit VRAM mode.
 *
 **/

#include "core.h"
#include "device.h"
#include "font.h"

enum {BG, FG};
static uchar colors[2];


/* Convert a 1bit bitmap to an 8bit bitmap */
static void planar2chunky(unsigned char *d, uint32 *s, int x, int y, int width, int height, int swidth, int dwidth)
{
	uint32 mask,m;
	uint32 startm = (0x80000000 >> (x%32));
	uint32 endm = (0x80000000 >> ((x+width)%32));
	uchar fg = 0x01;
	uchar bg = 0x00;
	int startx = x/32;
	int stopx = (x+width)/32;
	uint32 *sp = &s[startx + y*swidth];

	int smod = swidth - (stopx - startx) - 1;
	int dmod = dwidth - width;

	while(height--) {
		mask = startm;
		for(x = startx; x<=stopx; x++, sp++) {
			m = (x == stopx) ? endm : 0;
			for(; mask != m; mask /= 2)
				*d++ = (mask & *sp ? fg : bg);
			mask = 0x80000000;
		}

		d += dmod;
		sp += smod;
	}	
}

/* Pretty fast block copy (with color translation) */
inline void block_copy(uchar *dest, uchar *src, int width, int height, int swidth, int dwidth)
{
	uint16 wrd;
	register uint16 *d;
	register uchar *p = (uchar *)&wrd;
	register int w;
	register int odd = 0;
	int dmod;
	int smod = swidth-width;

	if((int)dest&1)
	{
		width--;
		odd = 1;
		dest = (uchar *)((int)dest & 0xFFFFFFFE);
		dwidth--;
	}
	if(width&1)
	{
		width--;
		odd += 2;
	}
	width = width>>1;
	dmod = (dwidth>>1)-width;
	d = (uint16 *)dest;

	switch(odd)
	{
	case 0:
		while(height--)
		{
			w = width;
			while(w--)
			{
				p[0] = colors[*src++];
				p[1] = colors[*src++];
				*d++ = wrd;
			}
			d += dmod;
			src += smod;
		}
		return;
	case 1:
		while(height--)
		{
			w = width;
			wrd = *d;
			p[1] = colors[*src++];
			*d++ = wrd;
			while(w--)
			{
				p[0] = colors[*src++];
				p[1] = colors[*src++];
				*d++ = wrd;
			}
			d += dmod;
			src += smod;
		}
		return;
	case 2:
		while(height--)
		{
			w = width;
			while(w--)
			{
				p[0] = colors[*src++];
				p[1] = colors[*src++];
				*d++ = wrd;
			}
			wrd = *d;
			p[0] = colors[*src++];
			*d = wrd;
			d += dmod;
			src += smod;
		}
		return;
	case 3:
		while(height--)
		{
			w = width;

			wrd = *d;
			p[1] = colors[*src++];
			*d++ = wrd;
			while(w--)
			{
				p[0] = colors[*src++];
				p[1] = colors[*src++];
				*d++ = wrd;
			}
			wrd = *d;
			p[0] = colors[*src++];
			*d = wrd;
			d += dmod;
			src += smod;
		}
		return;
	}
}

/* Pretty fast block copy (without color translation) */
/*
inline void block_copy2(uchar *dest, uchar *src, int width, int height, int swidth, int dwidth)
{
	uint16 wrd;
	register uint16 *d;
	register uchar *p = (uchar *)&wrd;
	register int w;
	register int odd = 0;
	int dmod;
	int smod = swidth-width;

	if((int)dest&1)
	{
		width--;
		odd = 1;
		dest = (uchar *)((int)dest & 0xFFFFFFFE);
		dwidth--;
	}
	if(width&1)
	{
		width--;
		odd += 2;
	}
	width = width>>1;
	dmod = (dwidth>>1)-width;
	d = (uint16 *)dest;

	while(height--)
	{
		w = width;
		if(odd&1)
		{
			w = width;
			wrd = *d;
			if(src[0])
				p[1] = src[0];
			src++;
			*d++ = wrd;
		}
		while(w--)
		{
			wrd = *d;
			if(src[0])
				p[0] = src[0];
			if(src[1])
				p[1] = src[1];
			src += 2;
			*d++ = wrd;
		}
		if(odd&2)
		{
			wrd = *d;
			if(src[0])
				p[0] = src[0];
			src++;
			*d = wrd;
		}
		d += dmod;
		src += smod;
	}
	return;
}
*/

//int ital_shift = 0;

inline void block_copy3(uchar *dest, uchar *src, int width, int height, int swidth, int dwidth)
{
	uint16 wrd;
	register uint16 *d;
	register uchar *p = (uchar *)&wrd;
	register int w;
	register int odd = 0;
	uint16 fg = colors[1];
	int dmod;
	int smod = swidth-width;

	if((int)dest&1)
	{
		width--;
		odd = 1;
		dest = (uchar *)((int)dest & 0xFFFFFFFE);
		dwidth--;
	}
	if(width&1)
	{
		width--;
		odd += 2;
	}
	width = width>>1;
	dmod = ((dwidth>>1)-width);

	d = (uint16 *)dest;

	while(height--)
	{
		w = width;
		if(odd&1)
		{
			w = width;
			wrd = *d;
			if(*src++)
				p[1] = fg;
			*d++ = wrd;
		}
		while(w--)
		{
			wrd = *d;
			if(*src++)
				p[0] = fg;
			if(*src++)
				p[1] = fg;
			*d++ = wrd;
		}
		if(odd&2)
		{
			wrd = *d;
			if(*src++)
				p[0] = fg;
			*d = wrd;
		}
		d += dmod;
		src += smod;
	}
	return;
}

/* Clear block to value */
inline void block_set(uchar *dest, int width, int height, int dwidth, uint16 v)
{
	uint16 wrd;
	register uint16 *d;
	register uchar *p = (uchar *)&wrd;
	register int w;
	register int odd = 0;
	int dmod;

	v |= (v<<8);

	if((int)dest&1)
	{
		width--;
		odd = 1;
		dest = (uchar *)((int)dest & 0xFFFFFFFE);
		dwidth--;
	}
	if(width&1)
	{
		width--;
		odd += 2;
	}
	width = width>>1;
	dmod = (dwidth>>1)-width;
	d = (uint16 *)dest;

	while(height--)
	{
		w = width;
		if(odd & 1)
		{
			wrd = *d;
			p[1] = v;
			*d++ = wrd;
		}
		while(w--)
			*d++ = v;
		if(odd & 2)
		{
			wrd = *d;
			p[0] = v;
			*d = wrd;
		}
		d += dmod;
	}
}

static Font *font_prepare(Font *font)
{
	if(!font->pixels)
		font->pixels = malloc(font->width * font->height);	
	planar2chunky(font->pixels, font->planar, 0, 0, font->width, font->height, (font->width+31)/32, font->width);
	return font;

}

void font_setcolor(int fg, int bg)
{
	colors[FG] = fg;
	colors[BG] = bg;
}

static uchar font_putmono(Font *font, char c, uchar *dest, int width)
{
	register int w;
	int solid = !(font->flags & FFLG_TRANSP);
	if(c < font->first || c > font->last)
		return 0;

	w = font->charwidth;
	if(dest)
	{
		if(c == ' ')
		{
			if(solid)
				block_set(dest, w, font->height, width, colors[BG]);
		}
		else
		{
			if(solid)
				block_copy(dest, &font->pixels[(c - font->first) * w], w, font->height, font->width, width);
			else
				block_copy3(dest, &font->pixels[(c - font->first) * w], w, font->height, font->width, width);
		}
	}
	return w;
}

static uchar font_putprop(Font *font, char c, uchar *dest, int width)
{
	register int offset,w;
	register int ff = font->first;
	int solid = !(font->flags & FFLG_TRANSP);

	if(c == ' ')
	{
		w = font->charwidth;
		if(dest && solid)
			block_set(dest, w, font->height, width, colors[BG]);
	} 
	else
	{
		if(c < ff || c > font->last)
			return 0;
		offset =  font->offsets[c - ff];
		w = font->offsets[c - ff + 1] - offset;
		if(dest)
		{
			if(solid)
				block_copy(dest, &font->pixels[offset], w, font->height, font->width, width);
			else
				block_copy3(dest, &font->pixels[offset], w, font->height, font->width, width);
		}
	}
	return w;
}

uchar font_putchar(Font *font, char c, uchar *dest, int width)
{
	int rc, fl;
	if(font->offsets)
	{
		if(font->flags & FFLG_BOLD)
		{
			font_putprop(font, c, dest, width);
			fl = font->flags;
			font->flags |= FFLG_TRANSP;
			rc = font_putprop(font, c, dest+1, width);
			font->flags = fl;
			return rc;
		}
		else
		return font_putprop(font, c, dest, width);
	}
	else
	{
		if(font->flags & FFLG_BOLD)
		{
			font_putmono(font, c, dest, width);
			fl = font->flags;
			font->flags |= FFLG_TRANSP;
			rc = font_putmono(font, c, dest+1, width);
			font->flags = fl;
			return rc;
		}
		else
		return font_putmono(font, c, dest, width);
	}
}

int font_text(Font *font, char *str, uchar *dest, int width)
{
	uchar *outw = dest;

	while(*str)
		dest += font_putchar(font, *str++, dest, width);
/*
	if(font->offsets)
		while(*str)
			dest += font_putprop(font, *str++, dest, width);
	else
		while(*str)
			dest += font_putmono(font, *str++, dest, width);
*/	
	return dest-outw;
}

Font *font_load(char *name)
{
	int size, pix_size, l;
	Font font;
	Font *rfont;
	int fd = open(name, 0);
	if(fd > 0)
	{
		read(fd, &font, 8);
	
		pix_size = ((font.width+31)&0xFFFFFFE0) * font.height;

		l = strlen(name);
		if(!(l & 1))
			l++;
		size = pix_size + sizeof(Font) + l + 1;
		if(font.flags & FFLG_PROPORTIONAL)
			size += (font.last - font.first + 1)*2;

		rfont = malloc(size);
		memcpy(rfont, &font, 8);

		rfont->name = (char *)&rfont[1];
		strcpy(rfont->name, name);
		rfont->pixels = (uchar *)&rfont->name[l+1];
		rfont->planar = malloc(pix_size/8);
		read(fd, rfont->planar, pix_size/8);
		font_prepare(rfont);
		free(rfont->planar);
		rfont->planar = NULL;

		if(rfont->flags & FFLG_PROPORTIONAL)
		{
			rfont->offsets = (uint16 *)&rfont->pixels[pix_size];
			read(fd, rfont->offsets, (rfont->last - rfont->first + 1)*2);
		} else
			rfont->offsets = NULL;

		close(fd);

		return rfont;
	}
	return NULL;
}
