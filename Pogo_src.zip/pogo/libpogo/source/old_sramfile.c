#include "core.h"
#include "device.h"
 
typedef struct _SRamFile
{
	struct _SRamFile *next;
	char name[32];
	uint16 pad;
	uint16 flags;
	uint32 length;
} SRamFile;

typedef struct
{
	SRamFile *file;
	uint32 pos;
} OpenFile;

static SRamFile *first = NULL;
static SRamFile *gap = NULL;
//uint32* gapend = NULL;

static char *sram_mem = (char *)0x0E000000;
static int sram_size = 64*1024;

static int openCount = 0;
static OpenFile openFiles[32];

//#define AFTER(f) (((char *)&f[1]) + f->length);
#define SET32(a, b) { char *d = (char *)&(a); char *s = (char *)&(b); *d++ = *s++; *d++ = *s++; *d++ = *s++; *d++ = *s++; }

//#define GET32(a, v) { char *s = (char *)&(a); char *d = (char *)&(v); *d++ = *s++; *d++ = *s++; *d++ = *s++; *d++ = *s++; }

static SRamFile *create_file(const char *name)
{
	int l;
	int zero = 0;
	SRamFile *f;

	if(gap)
	{
		SET32(l, gap->length);
		f = (SRamFile *)(((char *)&gap[1]) + l);
		
		SET32(f->next, gap->next)
		SET32(gap->next, f);
	}
	else
	{
		first = f = (SRamFile *)&sram_mem[16];
		SET32(f->next, zero);
	}
	gap = f;

	strcpy(f->name, name);
	SET32(f->length , zero);

	SET32(sram_mem[8], first);
	SET32(sram_mem[12], gap);

	return f;
}


static SRamFile *close_gap(SRamFile *f, SRamFile *prev, int up)
{
	int l;
	uchar *dest;
	SRamFile *next;
		
	SET32(l, f->length);
	SET32(next, f->next);

	if(up)
	{
		/* Move next file up to directly after this file */
		dest = (((uchar *)&f[1]) + l); /* Ptr to after file */
		SET32(l, next->length);
		memcpy8(dest, next, l + sizeof(SRamFile));
		SET32(f->next, dest);
	}
	else
	{
		/* Move this file down to directly before next */
		if(next)
			dest = (uchar *)next - l - sizeof(SRamFile);
		else
			dest = ((uchar *)&sram_mem[sram_size]) - l - sizeof(SRamFile);
		memmove8(dest, f, l + sizeof(SRamFile));
		SET32(prev->next, dest); 
		f = (SRamFile*)dest;
	}
	return f;
}

static SRamFile *bump_file(SRamFile *bfile, int size)
{
	SRamFile *next, *f;
	SRamFile *stack[32];
	int sp = 0;

	if(gap < bfile)
	{
		SRamFile *nf = NULL;
		/* Gap is before file, move files after gap (including file) upwards */
		f = gap;
		while(next != bfile)
		{

			SET32(next, f->next);
			nf = close_gap(f, NULL, 1);
			SET32(f, f->next);
		}
		SET32(bfile, nf->next);
	}
	else
	{ 
		/* Gap is after file, move files before gap (including gap) downwards*/

		f = bfile;
		while(f != gap)
		{
			stack[sp++] = f;
			SET32(f, f->next);
		}
		stack[sp] = gap;

		while(sp)
		{
			close_gap(stack[sp], stack[sp-1], 0);
			sp--;
		}
	}

	gap = bfile;
	SET32(sram_mem[12], gap);
	return gap;
}

static int sram_open(const char *name, int mode)
{
	SRamFile *lastf = NULL;
	SRamFile *f = first;
	int l;

	if(!*name)
	{
		OpenFile *of = &openFiles[openCount++];
		of->file = 0;
		of->pos = (uint32)first;
		return openCount-1;
	}

	while(f)
	{
		if(strcmp(f->name, name) == 0)
		{
			OpenFile *of = &openFiles[openCount++];
			of->file = f;
			of->pos = 0;
			SET32(l, f->length);
			return openCount-1;
		}
		lastf = f;
		SET32(f, f->next);
	}
	if(mode & O_CREAT)
	{
		if((f = create_file(name)))
		{
			OpenFile *of = &openFiles[openCount++];
			of->file = f;
			of->pos = 0;
			return openCount-1;
		}
	}

	return -1;
}

static int sram_write(int fd, const void *src, int size)
{
	char *p;
	int l;
	OpenFile *of = &openFiles[fd];
	SRamFile *f = of->file;

	SET32(l, f->length);

	if(of->pos == -1) {
		return -1;
	}

	if((of->pos + size > l) && gap != f)
		of->file = f = bump_file(f, size);

	p = ((char *)&f[1]) + of->pos;

	memcpy8(p, src, size);
	of->pos += size;
	if(of->pos > l)
		SET32(f->length, of->pos);

	return size;
}

static int sram_read(int fd, void *dest, int size)
{
	char *p;
	int l;
	OpenFile *of = &openFiles[fd];
	SRamFile *f = of->file;

	if(!f)
	{
		char *d = (char *)dest;
		while(of->pos && size >= 32)
		{
			f = (SRamFile *)of->pos;
			memcpy8(d, f->name, 32);
			d+=32;
			size-=32;
			SET32(f, f->next);
			of->pos = (int32)f;
		}
		return d-(char*)dest;
	}

	p = ((char *)&f[1]) + of->pos;

	SET32(l, f->length);

	if(of->pos == -1) {
		return -1;
	}

	of->pos += size;
	if(of->pos > l)
	{
		size -= (of->pos - l);
		of->pos = f->length;
	}

	memcpy8(dest, p, size);

	return size;

}

static int sram_close(int fd)
{
	OpenFile *of = &openFiles[fd];
	of->pos = -1;

	of = &openFiles[openCount-1];
	while(openCount && of->pos == -1) {
		openCount--;
		of = &openFiles[openCount-1];
	}
	return 0;
}

static int sram_remove(const char *name)
{
	return 0;
}

static Device sramdev;

void sram_init(void)
{
	int zero = 0;
	memset(&sramdev, 0, sizeof(Device));
	sramdev.open = sram_open;
	sramdev.close = sram_close;
	sramdev.read = sram_read;
	sramdev.write = sram_write;

	device_register(&sramdev, "/sram/", NULL, -1);

	if(strcmp(sram_mem, "MINISFS") == 0)
	{
		SET32(first, sram_mem[8]);
		SET32(gap, sram_mem[12]);
	}
	else
	{
		first = gap = NULL;
		memcpy8(sram_mem, "MINISFS", 8);
		SET32(sram_mem[8], zero);
		SET32(sram_mem[12], zero);
	}
}
