
void savesys_savelastgame();
int savesys_handleexec(char *current);
