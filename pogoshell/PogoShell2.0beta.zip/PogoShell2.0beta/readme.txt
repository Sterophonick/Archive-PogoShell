 POGOSHELL 2.0 BETA
--------------------
Released 11 Jan 2004


This is the first public release of Pogoshell 2.0 beta
There's no real documentation yet, feel free to experiment :)

There _will_ be bugs. If you think it's something I'm not aware
of you can post on the forum or even mail me.

*IMPORTANT NOTE*
The new sram filesystem is incompatible with previous!
If you start Pogshell with an old sram system in your cart
it will be erased!
Hopefully someone (possibly me) will make a tool to
convert it soon.

Again note - this is a BETA. A final version will be released
when I feel it is stable enough and the final features are in.


USING

Run "BUILD.BAT" to build a rom from your "root" directory
Now you can either:

* Run "TEST.BAT" to test your rom in Visual Boy Advance
* Flash "flashme.gba" to your cart
* Flash "pogo.gba" and "filesys.bin" separatly to your
  cart with any flash program - as long as "filesys.bin"
  is after "pogo.gba" the files will be found. If you
  put normal roms in between they should also be found
  by pogoshell


USERS

You dont have to bother with users, but L+SELECT lets you
choose between the users defined in .shell/users

Different users will not see each others sram-saves, but you
can use Copy/Paste to copy a file from one user to another.

User 100 is the textreader and all generated indexes are
saved as that user.


THEMES

Right now, ".shell/default.theme" is loaded - rename one of the
others to use that. The themes basically define the GUI
components - feel free to experiment.

The tool bmp2bm is used to create icons and backround bitmaps.
It's extremely primitive at the moment, just bmp2bm <infile> <outfile>
and pure green becomes transparent.


MAIN CHANGES SINCE v1.3

* Unified SRAM (one big bank) 
* Working XG1 support
* Completely themable (new GUI system) with background graphics
  and scrollbars 
* Color fonts 
* 16bit graphics 
* Internal BMP viewer 
* Simple multiuser (to have multiple saves for one game) 
* SRAM can be used for normal files (texts, mods etc) 
* Better support for mixing Pogoshell with other menu, and
  changing games without reflashing everything 
* Pogoshell detects roms not in the pogo filesystem but in the
  cart and puts them in a special folder 
* Multiboot as plugin - goomba & pocketnes runs as multiboot which
  means they take less space and works on any cart and emulator 
* Settable per plugin if savename should be taken from plugin name
  or file (rom) name 
* Preliminary RTC Support 


KNOWN BUGS / MISSING FEATURES

* No reset start
* No date from RTC
* Themes will be runtime switchable
* SRAM bank usage will be settable



-- Sasq
(jonas_minnberg@yahoo.se)
