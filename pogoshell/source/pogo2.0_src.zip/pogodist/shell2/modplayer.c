
#include <pogo.h>

#include "gba_defs.h"
#include "Nmodgcc.h"

typedef void (*VoidFunc)(void);
typedef uint32 (*IntFunc)(void);

extern void LZ77UnCompWram(void *Srcp, void *Destp);

//extern void __FarProcedure (void (*ptr)(), ...);  // Reference to routine in crt0.S
extern void __FarProcedure2 (void (*ptr)(), ...);  // Reference to routine in crt0.S


static volatile void mod_update(void)
{
	int i = GETW(REG_IF);
	if(i & TIMER1_INTR_FLAG)
	{
		__FarFunction((IntFunc)NMOD_Timer1iRQ);
	}
}

static Device moddev;

static int mod_open(const char *name, int flags)
{
	char tmp[80] = "";
	int size;
	char *s = (char *)name;

	if(*name != '/')
		strcpy(tmp, "/");
	strcat(tmp, name);

	int fd = open(tmp, 0);

	//fprintf(stderr, "MOD OPEN %s %d\n", name, fd);


	if(fd >= 0)
	{
		uchar *play = (uchar *)0x02000000;				// Play pos
		uchar *ptr = (uchar *)lseek(fd, 0, SEEK_MEM);	// Unpack from pos

		size = lseek(fd, 0, SEEK_END);
		lseek(fd, 0, SEEK_SET);

		if(!ptr)
		{
			ptr = (uchar *)0x02000000 + 120*1024 - size;
			read(fd, ptr, size);
		}

		close(fd);

		//fprintf(stderr, "seek %p\n", ptr);

		while(*s++ != '.');
		if(s[2] == 'z')
		{
				LZ77UnCompWram(ptr, play);
		}
		else
			play = ptr;

		__FarProcedure2((VoidFunc)NMOD_SetMasterVol, 64, 0);
		__FarProcedure2((VoidFunc)NMOD_SetMasterVol, 64, 1);
		__FarProcedure2((VoidFunc)NMOD_SetMasterVol, 64, 2);
		__FarProcedure2((VoidFunc)NMOD_SetMasterVol, 64, 3);
		__FarProcedure2((VoidFunc)NMOD_Play, play);

		return 0;
	}

	return -1;

}

static int mod_close(int fd)
{
	//int l;

	NMOD_Stop();
	//l = GETW(REG_IE);
    //SETW(REG_IE, l & (~TIMER1_INTR_FLAG));
	SETW(REG_IF, TIMER1_INTR_FLAG);
	return 0;
}


void mod_init(void)
{
	//int l;
	memset(&moddev, 0, sizeof(moddev));
	moddev.open = mod_open;
	moddev.close = mod_close;
	device_register(&moddev, "/mod", mod_update, -1);

	//SETW(REG_IME, 1);
	//l = GETW(REG_IE);
    //SETW(REG_IE, l | TIMER1_INTR_FLAG);
}

static int modfd = -1;

int mod_play(char *current)
{
	char tmp[128];
	char *p = current;
	//while(*p == '/') p++;
	//if(strncmp(p, "rom", 3) == 0) p += 3;
	//while(*p == '/') p++;

	sprintf(tmp, "/mod%s", p);

	//fprintf(stderr, "MOD %s\n", tmp);

	if(modfd >= 0)
		close(modfd);

	modfd = open(tmp, 0);
	return 1;
}

void mod_stop(void)
{
	if(modfd >= 0)
		close(modfd);
	modfd = -1;
}
