
void mod_init(void);
int mod_play(char *current);
void mod_stop(void);
