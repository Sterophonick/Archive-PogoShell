#ifndef WIDGETS_H
#define WIDGETS_H

#include "tricontainer.h"
#include "textbar.h"
#include "textflow.h"
#include "listview.h"
#include "textreader.h"

#endif
