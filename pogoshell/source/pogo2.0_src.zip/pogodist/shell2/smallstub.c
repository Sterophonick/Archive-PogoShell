#include <pogo.h>

void mod_init(void)
{
}

void mod_stop(void)
{
}

int mod_play(char *current)
{
	return -1;
}

void textreader_set_font(int n, Font *f)
{
}

int textreader_show_text(char *name)
{
	return -1;
}

int sram_convert(void)
{
	return -1;
}

void bmp_view(char *fname)
{
}

