#ifndef CURSOR_H
#define CURSOR_H

void cursor_update(void);
void cursor_set(int x, int y);
void cursor_show(int show);
void cursor_init(void);

#endif
