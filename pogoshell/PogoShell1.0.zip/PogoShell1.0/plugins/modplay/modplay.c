/*
 * MODPLAYER INTERFACE by Sasq / DCS in 20002
 *
 * Plays compressed and uncompressed mods or codewave converted mods
 * Uses libafm (by Hitmen) and the CodeWaves library for playing
 *
 * USAGE
 *  If started from PogoShell, it checks the file-exention:
 *    .mod  Normal Module
 *    .mdz  LZ77 Compressed module
 *    .cw   Normal Codewaves converted modules
 *    .cwz  LZ77 Compressed codewave module
 *
 *  If started as a normal rom (not from the shell) it just assumes it
 *  is followed by an uncompressed codewave module. Just use;
 *  COPY /B mod.bin+music.cw music.bin
 *
 * NOTE that the uncompressed size of a compressed file may not be larger
 * than 256KByte (you should realize why :)
 *
 */

#include "afm.h"
#include "gbaplayer.h"

#define SETW(adr, val) (*((volatile unsigned short*)adr) = val)

#define REG_BASE                0x04000000          // Registers
#define REG_IME         (REG_BASE + 0x208)  // Interrupt Master Enable
#define REG_IE          (REG_BASE + 0x200)  // Interrupt Enable
#define REG_IF          (REG_BASE + 0x202)  // Interrupt Request

#define VCOUNT  (*(volatile unsigned short*)0x04000006)
#define KEYS  (*(volatile unsigned short*)0x04000130)
#define BG_PALRAM ((volatile unsigned short*)0x05000000)

extern void LZ77UnCompWram(void *Srcp, void *Destp);

void play_mod(unsigned char *ptr)
{
	int i,go = 1;

    afm_install();
	afm_sound_param(0xFF>>2, 2);

    /* initialize module */
    afm_init(ptr);

    while(go) {
		while(VCOUNT < 30);

		//BG_PALRAM[0] = 0x001F;
		afm_update();
		//BG_PALRAM[0] = 0x0000;

		while(VCOUNT < 168);
		afm_sync();

		while(VCOUNT >= 168);
		
		/* Check for START+SELECT */
		i = ~KEYS;
		if((i & 0x08) == 0x08)
			go = 0;
    }

    afm_deinit();
}

void play_cw(unsigned char *ptr)
{
	int i,go = 1;

	MP_InitArm();
	MP_SetVolumeArm(100);
	MP_PlayModuleArm(ptr, 1);

    while(go) {	

		//BG_PALRAM[0] = 0x001F;
		MP_UpdateArm();
		//BG_PALRAM[0] = 0x0000;

		
		/* Check for START+SELECT */
		i = ~KEYS;
		if(i & 0x0E)
			go = 0;
    }
	MP_SetVolumeArm(0);
	MP_StopModuleArm();
	for(i=0; i<3; i++)
	{
		while(VCOUNT != 160);
		while(VCOUNT == 160);
		MP_UpdateArm();
	}
}

extern void __FarProcedure (void (*ptr)(), ...);
extern void doReset(void) __attribute__ ((section (".iwram")));

extern int __ewram_overlay_lma;
extern int __eheap_start;

int AgbMain(int argc, char **argv)
{
	unsigned int *q, *r, *p;

	q = &__eheap_start;
	r = &__ewram_overlay_lma;

	p = (unsigned int *)0x0203FC00;
	if(p[0] == 0xFAB0BABE)
	{
		char *s = (char *)&p[2];
		r = p[-1];
		while(*s++);
		while(*s++ != '.');
		if(s[2] == 'z')
		{
			LZ77UnCompWram(r, q);
			r = q;
		}
		if(*s == 'm')
			play_mod((unsigned char *)r);
		else
			play_cw((unsigned char *)r);
	}
	else
	{
		LZ77UnCompWram(r, q);
		play_cw((unsigned char *)q);
	}

	SETW(REG_IME, 1);
	SETW(REG_IE, 0);
	SETW(REG_IF, 0);

	__FarProcedure(doReset);

	return 0;
}
