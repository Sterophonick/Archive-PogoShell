#include "pogo.h"
#include "gammatab.h"

int show_bmp(char *name)
{
	int i,c,l;
	uint16 bpp;
	uchar colors[3*256];
	uint32 start, size, width, height;
	int fd = open(name, 0);

	fprintf(stderr, "%s -> %d\n", name, fd);
	if(fd >= 0) {
		int sfd = open("/dev/screen", 0);
		uint16 *ptr, *p = (uint16 *)lseek(sfd, 0, SEEK_MEM);
		lseek(fd, 10, SEEK_SET);
		read(fd, &start, 4);
		read(fd, &size, 4);
		read(fd, &width, 4);
		read(fd, &height, 4);
		read(fd, &bpp, 2);
		read(fd, &bpp, 2);
		if(bpp == 8)
		{
			lseek(fd, size+14, SEEK_SET);
			for(i=0; i<256; i++) {
				read(fd, &colors[i*3], 3);
				colors[i*3] = gammatab[colors[i*3]]*8;
				colors[i*3+1] = gammatab[colors[i*3+1]]*8;
				colors[i*3+2] = gammatab[colors[i*3+2]]*8;
				c = colors[i*3];
				colors[i*3] = colors[i*3+2];
				colors[i*3+2] = c;
				lseek(fd, 1, SEEK_CUR);
			}
			ioctl(sfd, SC_SETPAL, colors, 0, 256);
		}
		lseek(fd, start, SEEK_SET);

		if(bpp == 8)
		{
			ioctl(sfd, SC_SETMODE, 1);
			ptr = p+120*(height-1) + (120-width/2)/2;
			for(; ptr >= p; ptr -= 120) {
				read(fd, ptr, (width+3)&0xFFFFFFFC);
			}
		} else
		if(bpp == 16)
		{
			ioctl(sfd, SC_SETMODE, 2);
			ptr = p+240*(height-1) + (240-width/2)/2;
			for(; ptr >= p; ptr -= 240) {
				read(fd, ptr, 2*((width+3)&0xFFFFFFFC));
			}
		}
		else
		if(bpp == 24)
		{
			unsigned char cols[240*3];
			ioctl(sfd, SC_SETMODE, 2);
			l = height;
			ptr = p+240*(height-1) + (240-width)/2;
			while(l--)
			{
				read(fd, cols, 3*width);
				for(i=0; i<width*3; i+=3)
					*ptr++ = ((cols[i]&0xf8)<<7) | ((cols[i+1]&0xf8)<<2) | ((cols[i+2]&0xf8)>>3);
				ptr -= width*2;
			}
		}

		close(fd);
		close(sfd);
		return 1;
	}
	return 0;
}

extern int __ewram_overlay_lma;


int main(int argc, char **argv)
{
	int c;
	unsigned int *p = (unsigned int *)0x06000000;
	int l = 60*160;
	while(l--)
		*p++ = 0;

	ioctl(0, IO_SETMODE, KM_RAW);
	while(getchar() != EOF);

	if(argc >1)
		show_bmp(argv[1]);
	else
		show_bmp("pic.bmp");

	while(((c = getchar()) == EOF) || (c&0x80));

	return 0;
}
