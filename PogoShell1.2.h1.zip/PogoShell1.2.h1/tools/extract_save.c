// extract_save.c : Defines the entry point for the console application.
//

#include <stdio.h>

const char *ID = "MINSF2";

typedef struct _SRamFile
{
	unsigned long next;
	char name[32];
	unsigned int flags;
	unsigned long length; 
} SRamFile;

typedef struct _BankHeader
{
	char ident[8];
	unsigned long first_ptr;
	unsigned long gap_ptr;
} BankHeader;

/*******************************************************************************
  Decompress a save file
*******************************************************************************/
int decompress(char *buffer, unsigned long size)
{
  char tempbuf[65536];
  unsigned long i=0;
  unsigned long j=0;
  unsigned char tempchar;
  unsigned int state=0;

  //return 0; //for compressed output

  memset(tempbuf,0,65536);
  i=8;
  while(i<size && j<65536)
  {
    switch(state)
    {
    case 0: //non-repeating
      //printf("Non-repeating: i=%u, j=%u\n",i,j);
      tempchar=buffer[i++];
      if(tempchar==0)
      {
        //i++;
        state=1;
      }
      else
      {
        //printf("Tempchar: %u\n",tempchar);
        if(j+tempchar > 65536) return 1;
        memcpy(&tempbuf[j],&buffer[i],tempchar);
        i+=tempchar;
        j+=tempchar;
        //if(tempchar!=0xff) state=1;
        state=1;
        //else printf("Hit 0xff non-repeating at %u..........\n",i);
      }
      break;
      
    case 1: //repeating
      //printf("    Repeating: i=%u, j=%u\n",i,j);
      tempchar=buffer[i++];
      if(tempchar==0)
      {
        //i++;
        //state=0;
      }
      else
      {
        //printf("Tempchar: %u\n",tempchar);
        if(j+tempchar > 65536) return 1;
        memset(&tempbuf[j],buffer[i],tempchar);
        i+=1;
        j+=tempchar;
        if(tempchar!=0xff) state=0;
        break;
      }
    }
  }

  memcpy(buffer,tempbuf,65536);

  return 0;
}

/*******************************************************************************
  Main program
*******************************************************************************/
int main(int argc, char* argv[])
{
	long	i;

    char    inputbuf[4][65536];
    char    outputbuf[65536];
    BankHeader  bank_header;
    SRamFile    sram_header;
    unsigned long current_pointer;
	FILE *fpi, *fpo;

    if(argc<2)
	{
		printf("Usage: extract_save <savefile>\n");
		printf("Press [ENTER] to continue...\n");
        getchar();
		return 0;
	}

	//read stuff in
	fpi = fopen(argv[1], "rb");
	printf(".");
    for(i=0;i<4;i++)
    {
      if(!fread(inputbuf[i],1,65536,fpi) && i==0)
      {
		printf("Error: inputfile not valid\n");
		printf("Press [ENTER] to continue...\n");
        getchar();
		return 0;
      }
	printf(".");
    }
    fclose(fpi);
    
    //convert the data
    for(i=0;i<4;i++)
    {
        memcpy(&bank_header,inputbuf[i],sizeof(bank_header));
        sram_header.next=bank_header.first_ptr;
        if(memcmp(&bank_header.ident,ID,6)==0) //bank contains compressed data
        {
            
            while(sram_header.next!=0)
            {
                current_pointer=sram_header.next-0x0E000000;
                memcpy(&sram_header,&inputbuf[i][current_pointer],36);
                if(memcmp(sram_header.name,"DUMMY",5) &&
                    memcmp(sram_header.name,"last_exec",9) &&
                    memcmp(sram_header.name,".state",6))
                {
                    memcpy(&sram_header.length,&inputbuf[i][current_pointer+38],4);
                    memset(outputbuf,0,sizeof(outputbuf));
                    memcpy(outputbuf,&inputbuf[i][current_pointer+42],sram_header.length);
                    
                    //printf("Decompressing %s\n",sram_header.name);
                    if(decompress(outputbuf,sram_header.length)==0)
                    {
                        
                        //write the file
                        fpo = fopen(sram_header.name, "wb");
                        fwrite(outputbuf,1,sizeof(outputbuf),fpo);
                        fclose(fpo);
                        
                        printf("%s extracted!\n",sram_header.name);
                    }
                    else
                    {
                        printf("Error decompressing %s\n",sram_header.name);
                    }
                }
            }
        }
    }
    
    return 0;
}
