#include <stdio.h>

/*
Mainly:
<p> inserts 2 LFs
<br> one LF

any <h?> inserts LF and starts bold
<b> starts bold
</b> stops bold
</h?> inserts LF, stops bold
<li> inserts LF, ' ',*
*/

//#define BOLD(x) (*x++ = '[')
//#define NOBOLD(x) (*x++ = ']')
#define BOLD(x) (strcpy(x, "\033[2m"), x += 4)
#define NOBOLD(x) (strcpy(x, "\033[0m"), x += 4)

int spaces = 0;

void dospace(char **p)
{
	if(spaces)
		*(*p)++ = ' ';
	spaces = 0;
}

void handle_tag(char *tag, char **out)
{
	char *dest = *out;
	printf("Tag <%s>\n", tag);
	//spaces = 0;
	if(stricmp(tag, "p") == 0)
	{
		spaces = 0;
		//dospace(&dest);
		*dest++ = 10;
	}
	else
	if((toupper(tag[0]) == 'H') && (isdigit(tag[1])))
	{
		spaces = 0;
		//dospace(&dest);
		*dest++ = 10;
		BOLD(dest);
	}
	else
	if((strnicmp(tag, "/H", 2) == 0) && (isdigit(tag[2])))
	{
		spaces = 0;
		//dospace(&dest);
		NOBOLD(dest);
		*dest++ = 10;
	}
	else
	if(stricmp(tag, "LI") == 0)
	{
		spaces = 0;
		//dospace(&dest);
		strcpy(dest, "\n  * ");
		dest += 5;
	}
	else
	if(strcmp(tag, "b") == 0)
	{
		dospace(&dest);
		BOLD(dest);
	}
	else
	if(strcmp(tag, "/b") == 0)
	{
		dospace(&dest);
		NOBOLD(dest);
	}
	*out = dest;
}

void handle_spec(char *s, char **out)
{
	char *dest = *out;
	if(strcmp(s, "quot") == 0)
		*dest++ = '\"';
	*out = dest;
}

int tag_mode = 0;
char *dest;

void parse_line(char *in, char *out)
{
	char tag[128];
	
	if(tag_mode)
		goto tag;

	while(*in)
	{
		switch(*in)
		{
		case '&':
			if(spaces)
				*out++ = ' ';
			spaces = 0;

			in++;
			dest = tag;
			while(*in && *in != ';')
				*dest++ = *in++;
			*dest = 0;
			handle_spec(tag, &out);
			break;
		case '<':
			in++;
			dest = tag;
tag:
			while(*in && *in != '>')
			{
				*dest++ = *in++;
			}
			if(*in)
			{
				*dest = 0;
				handle_tag(tag, &out);
				tag_mode = 0;
			}
			else
				tag_mode = 1;
			break;
		case ' ':
		case 10:
		case 13:
			spaces++;
			break;
		default:
			if(spaces)
				*out++ = ' ';
			*out++ = *in;
			spaces = 0;
			break;
		}
		in++;
	}
	spaces++;
	*out = 0;
}


char buf1[16384];
char buf2[16384];

int main(int argc, char **argv)
{
	FILE *fp1 = fopen(argv[1], "rb");
	FILE *fp2 = fopen(argv[2], "wb");

	if(!fp1)
	{
		printf("No input file\n");
		return 0;
	}
	if(!fp2)
	{
		printf("No output file\n");
		return 0;
	}

	while(fgets(buf1, sizeof(buf1), fp1))
	{
		buf1[strlen(buf1)-1] = 0;
		parse_line(buf1, buf2);
		fwrite(buf2, 1, strlen(buf2), fp2);
	}
	fclose(fp1);
	fclose(fp2);
	return 0;
}
