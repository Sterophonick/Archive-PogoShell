/*
 * MAKEFS sourcecode (makefs.c) - created by Jonas Minnberg 2002
 *
 * Generates rom filesystems and adds to a GBA binary
 *
 * Part of the pogo distribution.
 * Do what you want with this but please credit me.
 * -- jonas@nightmode.org
 ****/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>

#ifdef WIN32

#include <io.h>

struct dirent
{
	char *d_name;
};

typedef struct
{
	struct dirent de;
	struct _finddata_t fd;
	int handle;
} DIR;


DIR *opendir(char *name)
{
	char tmp[256];
	DIR *dir = malloc(sizeof(DIR));
	dir->de.d_name = NULL;
	sprintf(tmp, "%s/*", name);
	//printf("Looking for %s\n", tmp);
	dir->handle = _findfirst(tmp, &dir->fd);
	return dir;
}

struct dirent *readdir(DIR *dir)
{
	int rc = dir->handle;
	if(dir->de.d_name)
		rc = _findnext(dir->handle, &dir->fd);
	if(rc == -1)
		return NULL;
	dir->de.d_name = dir->fd.name;
	return &dir->de;
}

void closedir(DIR *dir)
{
	_findclose(dir->handle);
	free(dir);
}

#else
#include <dirent.h>
#endif // WIN32


typedef struct
{
	char name[32];
	int size;
	int start;

} RomDir;

#define PAD_FILE(fp) { int l = ftell(fp); if(l % 4) fwrite(&l, 1, 4-(l % 4), fp); }

int old_cart = 0;

const unsigned char good_header[] =
{
	36,255,174,81,105,154,162,33,61,132,130,10,
	132,228,9,173,17,36,139,152,192,129,127,33,163,82,190,25,
	147,9,206,32,16,70,74,74,248,39,49,236,88,199,232,51,
	130,227,206,191,133,244,223,148,206,75,9,193,148,86,138,192,
	19,114,167,252,159,132,77,115,163,202,154,97,88,151,163,39,
	252,3,152,118,35,29,199,97,3,4,174,86,191,56,132,0,
	64,167,14,253,255,82,254,3,111,149,48,241,151,251,192,133,
	96,214,128,37,169,99,190,3,1,78,56,226,249,162,52,255,
	187,62,3,68,120,0,144,203,136,17,58,148,101,192,124,99,
	135,240,60,175,214,37,228,139,56,10,172,114,33,212,248,7
};

/*
 If file first_child = NULL, otherwise first dir/file in directory
 next is next file/dir in parent dir
*/
typedef struct _DirFile
{
	char name[256];
	int size;
	struct _DirFile *next;
	struct _DirFile *first_child;
	int filetype;
	int offset;
} DirFile;

int bin_offset = 0;
int bincount = 0;
int smallcount = 1;
DirFile *binfiles[128];

const char spaces[] = "                                                            ";

void print_tree(DirFile *df, int l)
{
	if(df->first_child)
	{
		printf("%.*s[%s]\n", l*2, spaces, df->name);
		df = df->first_child;
		while(df)
		{
			print_tree(df, l+1);
			df = df->next;
		}
	}
	else
		printf("%.*s%s (%d bytes)\n", l*2, spaces, df->name, df->size);
}

int recsize(DirFile *df)
{
	DirFile *f;
	int size = 0;
	if(df->filetype != 1)
		size = (df->size+3)&0xfffffffc;
	if(df->first_child)
	{
		f = df->first_child;
		while(f)
		{
			size += recsize(f);
			size = (size+3)&0xfffffffc;
			f = f->next;
		}
	}
	return size;
}

int recbinsize(DirFile *df)
{
	DirFile *f;
	int size = 0;
	if(df->filetype == 1)
		size = df->size;
	if(df->first_child)
	{
		f = df->first_child;
		while(f)
		{
			size += recbinsize(f);
			f = f->next;
		}
	}
	return size;
}

void cutname(char *dst, char *src, int len)
{
	char *p = strrchr(src, '.');
	strncpy(dst, src, len);
	if(p)
		strcpy(dst+len-strlen(p), p);
}

void dump_tree(DirFile *df, FILE *outfp, int offset)
{
	RomDir dirbuf[256];
	int i,rc;
	DirFile *f;
	if(df->first_child)
	{
		/* Count files */
		f = df->first_child;
		i = 0;
		while(f)
		{
			i++;
			f = f->next;
		}
		offset += (i * sizeof(RomDir));


		/* Dump dir-file */
		f = df->first_child;
		i = 0;
		while(f)
		{
			char *p;
			memset(dirbuf[i].name, 0, 32);
			p = strrchr(f->name, '/');
			if(p)
				p++;
			else
				p = f->name;
			cutname(dirbuf[i].name, p, 31);
			//strncpy(dirbuf[i].name, p, 32);
			dirbuf[i].size = f->size;
			if(f->first_child)
				dirbuf[i].size |= 0x80000000;
			if(f->filetype == 1)
			{
				dirbuf[i++].start = bin_offset + f->offset;
				//bin_offset += recbinsize(f);
			}
			else
			{
				dirbuf[i++].start = offset;
				rc = recsize(f);
				//printf("%s has size %d\n", f->name, rc);
				offset += rc;
			}
			f = f->next;
		}
		//printf("Dumping dir-header for '%s' with %d entries\n", df->name, i);
		fwrite(dirbuf, 1, sizeof(RomDir)*i, outfp);

		f = df->first_child;
		i = 0;
		while(f)
		{
			//printf("Dumping %s to %d\n", f->name, dirbuf[i].start);
			dump_tree(f, outfp, dirbuf[i++].start);
			f = f->next;
		}
	}
	else
	if(df->size && (df->filetype != 1))
	{
		FILE *fp = fopen(df->name, "rb");
		char *ptr = malloc(df->size);
		fread(ptr, 1, df->size, fp);
		//printf("Dumping file '%s' size %d offset 0x%x \n", df->name, df->size, offset);
		fwrite(ptr, 1, (df->size+3)&0xfffffffc , outfp);
		fclose(fp);
		free(ptr);
	}
}


void make_tree(DirFile *df)
{
	DIR *dir;
	struct dirent *d;
	struct stat statbuf;
	DirFile *p, *lastp;
	int l = strlen(df->name);
	if(df->name[l-1] == '/')
		df->name[l-1] = 0;
	if(stat(df->name, &statbuf) != -1)
	{  
		if(statbuf.st_mode & S_IFDIR)
		{
			int i = 0;
			lastp = NULL;
			df->first_child = NULL;
			dir = opendir(df->name);
			p = NULL;
			while((d = readdir(dir)))
			{
				if((strlen(d->d_name) > 2) || d->d_name[0] != '.')
				{
					p = malloc(sizeof(DirFile));
					if(df->first_child == NULL)
						df->first_child = p;
					sprintf(p->name, "%s/%s", df->name, d->d_name);
					make_tree(p);
					if(lastp)
						lastp->next = p;
					lastp = p;
					i++;
				}
			}
			if(p)
				p->next = NULL;
			df->size = i*sizeof(RomDir);
			closedir(dir);
		}
		else
		{
			char *p = strrchr(df->name, '.');
			if(p)
			{
				/* Lowercase extention */
				char *q = ++p;
				while(*q)
				{
					*q = tolower(*q);
					q++;
				}

				if((strcmp(p, "bin") == 0) ||
				   (strcmp(p, "gba") == 0))
				{
					df->filetype = 1;
					if(old_cart)
					{
						//printf("Checking binfile %s %d\n", df->name, statbuf.st_size);
						if(statbuf.st_size <= 32768)
						{
							binfiles[smallcount] = df;
							smallcount += 2;
						}
						else
						{
							binfiles[bincount] = df;
							bincount += 2;
						}
					}
					else
						binfiles[bincount++] = df;
				}
			}

			df->first_child = NULL;
			df->size = statbuf.st_size;
		}
	}
}


RomDir *rootdir = NULL;

static unsigned int magic = 0xFAB0BABE;

#define BUF_SIZE 32*1024

unsigned char buf[BUF_SIZE];

int main(int argc, char **argv)
{
	int bootsize;
	int rc,i,j,l;
	int total = 0;
	char *inrom = NULL;
	char *outrom = NULL;
	char *rootdir = NULL;
	FILE *fp, *infp;
	DirFile df;

	for(i=0; i<128; i++)
		binfiles[i] = NULL;

	for(i=1;i<argc; i++)
	{
		if(argv[i][0] == '-')
		{
			switch(argv[i][1])
			{
			case 'o':
				printf("(Old) Turbo cart mode\n");
				old_cart = 1;
				break;
			}
		}
		else
		{
			if(!inrom)
				inrom = argv[i];
			else
			if(!outrom)
				outrom = argv[i];
			else
			if(!rootdir)
				rootdir = argv[i];
		}
	}


	if(!(inrom && outrom && rootdir))
	{
		printf("Usage: makefs [-old] <infile> <outfile> <rootdir>\n");
		return 0;
	}

	strcpy(df.name, rootdir);
	df.next = NULL;

	fp = fopen(outrom, "wb");
	infp = fopen(inrom, "rb");
	if(!infp)
	{
		printf("Could not open infile (%s)\n", inrom);
		return 0;
	}
	if(!fp)
	{
		printf("Could not open infile (%s)\n", outrom);
		return 0;
	}

	make_tree(&df);
	print_tree(&df, 0);
	rc = BUF_SIZE;
	while(rc == BUF_SIZE)
	{
		rc = fread(buf, 1, BUF_SIZE, infp);
		if(rc < BUF_SIZE)
			memset(&buf[rc], -1, BUF_SIZE-rc);
		fwrite(buf, 1, BUF_SIZE, fp);
		total += BUF_SIZE;
	}

	bootsize = total;

	if(old_cart && (smallcount > bincount))
		bincount = smallcount;

	total = 0;
	for(i=0; i<bincount; i++)
	{
		if(binfiles[i])
		{
			FILE *bfp = fopen(binfiles[i]->name, "rb");
			rc = BUF_SIZE;
			l = 0;
	
			if(old_cart)
			{
				/* Pad to next legal offset */
				memset(buf, -1, BUF_SIZE);
				//printf("Padding from %x to nearest oldcart alignment\n", total+bootsize);
				while((bootsize + total) & 0x003F7FFF)
				{
					fwrite(buf, 1, BUF_SIZE, fp);
					total += BUF_SIZE;
				}
			}

			printf("Rom %d (%s) starts at %p\n", i, binfiles[i]->name, total+bootsize);
			while(rc == BUF_SIZE)
			{
				rc = fread(buf, 1, BUF_SIZE, bfp);
				if(rc < BUF_SIZE)
					memset(&buf[rc], -1, BUF_SIZE-rc);
				if(!l && (strstr(binfiles[i]->name, ".plugins") == NULL) )
				{
					int cc = 0;
					for(j=0xA0; j<0xBD; j++)
						cc += buf[j];

					buf[j] = (0-(0x19+cc)) & 0xff;;

					memcpy(&buf[4], good_header, sizeof(good_header));
					buf[0xb2] = 0x96;
				}
				fwrite(buf, 1, BUF_SIZE, fp);
				l+=BUF_SIZE;
			}
			binfiles[i]->offset = total;
			total += l;
			binfiles[i]->size = l;
			fclose(bfp);
		}
	}

	bin_offset = 0-total-8;

	fwrite(&magic, 1, 4, fp);
	fwrite(&df.size, 1, 4, fp);
	dump_tree(&df, fp, 0);
	fclose(fp);
	return 0;
}
