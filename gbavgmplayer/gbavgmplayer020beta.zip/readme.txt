GBA VGM Player 0.20 beta
========================

20060716

by Maxim


What is it?
===========

It's a GBA stub and Pogoshell plugin that will play VGM files. See 
http://www.smspower.org/music/ for information on the VGM format.


How do I use it?
================

Easy way: get "GBA VGM Player ROM Builder".

Alternatively:

Put VGM files (as compressed .vgz or uncompressed .vgm) into the "vgms"
directory. Run "Go.bat" (which may not work if you don't have Windows
XP) to build a ROM out of them.

Put that onto a flashcard (there's not much point playing it on an
emulator) and listen to magical VGM goodness everywhere you go.

Controls:

D-pad left, right: skip track
Hold A to skip 10 tracks at a time, B to skip 100.

Start: pause
Select: keylock; cycles between unlocked, locked and locked with no
display.

A+B: toggle shuffle

D-pad up, down: select loop count
I assume you're familiar with this concept, since it's different for
VGMs than it is for most music. The number is how many times a looped
section will be played (from 1 to 9); instead of zero, there is a
circle which means it will loop forever - so it will never advance to
another track in this mode, *unless the track is not looped* - this
setting has no effect on non-looped tracks.


But I don't have Windows XP!
============================

Then either figure it out yourself (read Go.bat) or use "GBA VGM Player
ROM Builder".


Pogoshell support
=================

Preliminary Pogoshell support has been added. Copy gbavgmplayer.gba to
the plugins folder and add a line like this:

vgm 8 gbavgmplayer.gba 1

to pogo.cfg. You can LZO compress your VGM files using the compressor
in the tools\ folder of this distribution, the plugin will autodetect
the compression. If your files are GZip compressed (usually with the
extension VGZ) then you'll have to decompress them, see the batch file
for how that can be done.


Frequently asked questions
==========================

Q. Doesn't it support YM2413/YM2612/YM2151?
A. No way, no chance. It's possible an accurate FM chip emulator could
   be written in assembly, but it won't be by me. I don't have the time
   or inclination to learn a new assembly language just for this.

Q. What's the sampling rate?
A. It's actually at 20kHz, not 32kHz as the GBA is capable of at its
   peak. But the antialiasing effect means you can hardly tell the
   difference anyway.

Q. Why does file X play badly, with clicks and stutters and stuff?
A. The amount of CPU time needed depends on the data being played and
   some data uses more CPU time than others. Some samples play back OK,
   some don't. If you find a music track that stutters, let me know and
   I' ll see about fixing it. However, first optimise the VGM data
   using VGMTool: http://www.smspower.org/music/vgmtools.shtml#tools
   This reduces the amount of data without affecting the output, which
   helps save CPU time for sound chip emulation.

Q. Why don't you use the GB square wave generators instead?
A. Because I don't want to. I don't believe it is possible to
   accurately convert data to make it play back properly on those; it's
   only good enough for a fast SMS emulator's sound emulation.

Q. Why does it put the files in the wrong order?
A. The GBFS system I'm using (made by Damian Yerrick) is designed to
   support finding data from its filename so to make the search fast,
   all files are sorted alphabetically. Since I'm not using that
   feature, I made "GBA VGM Player ROM Builder" which allows you to
   choose the ordering, but using the batch file (which uses gbfs.exe
   underneath) will always give alphabetical ordering by filename.


Credits
=======

This is based upon GBA GSM Player by Damian Yerrick - see
http://www.pineight.com. His code is based on GPL and LGPL stuff so
mine is too. Viral, huh?

The ROM builder is not GPL or open source.

The GZip utility is by the GZip people, gbfs is by Damian Yerrick.

I am not a GBA coder. Don't expect too much. If you're willing to help
make it better then let me know because I haven't got a clue.

Apple might kill me for using their font. And their copyrighted shuffle
logo. Whoops.


Possibly still to come
======================

- More pretty graphics.
- Better text support (variable width).
- Pauses between tracks.
- Fadeout like in the plugin.


History
=======

0.1 24/4/2005
First version: basic looping playback with GD3 tag support.

0.11 24/4/2005
Added sources and COPYING stuff to comply with GPL. Added shuffle
support.

0.15 2/5/2005
Added tone channel antialiasing to vastly increase the sound quality.
Added loop count configurability and fast-forward mode.

0.16 3/5/2005
Fixed a bug with the keylock functionality.

0.17 22/10/2005
Optimised SN76489 emulator to natively generate 8-bit values. Increased
sampling rate to use the extra CPU time. Added total length and total
tracks to UI.

0.20 ??/??/2006
Added Pogoshell support.
Added LZO compression support.
Added tri-state locking.
Fixed(?) handling of newer (v1.50) VGM files.
Added support for SN76489 variant parameters, so BBC music will sound
right.