/* Get the worst-case maximum buffer size needed to compress data of a given size */
unsigned int lzo_dll_max_compressed_size(unsigned int uncompressed_size);

/* Decompress from buffer *in of size in_len to buffer *out of size out_bufsize,
 * returns decompressed actual size in out_len,
 * returns negative on error, 0 on success
 */
int lzo_dll_compress(char *in, unsigned int in_len, char *out, unsigned int out_bufsize, unsigned int *out_len);
