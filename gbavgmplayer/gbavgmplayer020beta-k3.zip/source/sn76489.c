#define ANTIALIAS_CHANNEL0
#define ANTIALIAS_CHANNEL1
#define ANTIALIAS_CHANNEL2

#include <string.h>
#include "sn76489.h"
#include "profile.h"

#include <limits.h> /* for INT_MIN */
#define NO_ANTIALIAS 32
#define FIXED_POINT_FRACTION_BITS 12 /* How many bits are the fractional part for fixed-point - tweaked for how it's used here and likely inputs (eg. clock mustn't overlow it) */
#define FIXED_POINT_SIGN_PART     0x80000000 /* bitmask for sign bit */
#define FIXED_POINT_INTEGER_PART  0x7FFFF000 /* bitmask for integer part */
#define FIXED_POINT_FRACTION_PART 0x00000FFF /* bitmask for fraction part */

#define NOISEINITIALSTATE   0x8000  /* Initial state of shift register */
//#define PSG_CUTOFF          0x6     /* Value below which PSG does not output */

#include "directsound_settings.h"
#define PSG_CUTOFF (3579545/16/SAMPLING_RATE) // I can't output any higher anyway, assuming normal clocks

int PSGVolumeValues[]
#ifndef WIN32
__attribute__ ((section (".iwram")))
#endif
= {
   25, 20, 16, 13, 10, 8, 6, 5, 4, 3, 3, 2, 2, 1, 1,0
};

// Putting these in IWRAM should make it faster?
SN76489_Context SN76489
#ifndef WIN32
__attribute__ ((section (".iwram")))
#endif
;

#ifndef WIN32
extern int dv(int, int) __attribute__((long_call));
#else
int dv(int n1,int n2)
{
  return n1/n2;
};
#endif

void SN76489_Init(int PSGClockValue, int SamplingRate, int PSGFeedback, int PSGSRWidth)
{
    SN76489.dClock=(PSGClockValue<<(FIXED_POINT_FRACTION_BITS-4))/SamplingRate;
    SN76489.NoiseSRWidth = PSGSRWidth;
    SN76489.NoiseFeedback = PSGFeedback;
    SN76489_Reset();
}

void SN76489_Reset()
{
    int i;

    for(i = 0; i <= 3; i++)
    {
        /* Initialise PSG state */
        SN76489.Registers[2*i] = 1;         /* tone freq=1 */
        SN76489.Registers[2*i+1] = 0xf;     /* vol=off */
        SN76489.NoiseFreq = 0x10;

        /* Set counters to 0 */
        SN76489.ToneFreqVals[i] = 0;

        /* Set flip-flops to 1 */
        SN76489.ToneFreqPos[i] = 1;

        /* Set intermediate positions to do-not-use value */
        SN76489.IntermediatePos[i] = NO_ANTIALIAS;
    }

    SN76489.LatchedRegister=0;

    /* Initialise noise generator */
    SN76489.NoiseShiftRegister=NOISEINITIALSTATE;

    /* Zero clock */
    SN76489.Clock=0;

}

void SN76489_Write(int data)
{
    if (data&0x80)
    {
        /* Latch/data byte  %1 cc t dddd */
        SN76489.LatchedRegister=((data>>4)&0x07);
        SN76489.Registers[SN76489.LatchedRegister]=
            (SN76489.Registers[SN76489.LatchedRegister] & 0x3f0)    /* zero low 4 bits */
            | (data&0xf);                                 /* and replace with data */
    } else
    {
        /* Data byte        %0 - dddddd */
        if (!(SN76489.LatchedRegister%2)&&(SN76489.LatchedRegister<5))
            /* Tone register */
            SN76489.Registers[SN76489.LatchedRegister]=
                (SN76489.Registers[SN76489.LatchedRegister] & 0x00f)    /* zero high 6 bits */
                | ((data&0x3f)<<4);                           /* and replace with data */
        else
            /* Other register */
            SN76489.Registers[SN76489.LatchedRegister]=data&0x0f;       /* Replace with data */
    }
    switch (SN76489.LatchedRegister)
    {
    case 0:
    case 2:
    case 4: /* Tone channels */
        if (SN76489.Registers[SN76489.LatchedRegister]==0) SN76489.Registers[SN76489.LatchedRegister]=1;    /* Zero frequency changed to 1 to avoid div/0 */
        break;
    case 6: /* Noise */
        SN76489.NoiseShiftRegister=NOISEINITIALSTATE;   /* reset shift register */
        SN76489.NoiseFreq=0x10<<(SN76489.Registers[6]&0x3);  /* set noise signal generator frequency */
        break;
    }
}

void SN76489_Update(signed char *buffer, int length)
{
    int j;

    for(j = 0; j < length; j++)
    {
        buffer[j]=SN76489.Channels[0]+SN76489.Channels[1]+SN76489.Channels[2]+SN76489.Channels[3];

        SN76489.Clock+=SN76489.dClock;
        SN76489.NumClocksForSample=(SN76489.Clock)>>FIXED_POINT_FRACTION_BITS;  /* truncate to integer */
        SN76489.Clock&=FIXED_POINT_FRACTION_PART; /* remove integer part, value should be +ve so clobbering sign bit is OK */

        /* Tone channels */
        if (SN76489.Registers[0]>PSG_CUTOFF)
        {
          SN76489.ToneFreqVals[0]-=SN76489.NumClocksForSample;
#ifdef ANTIALIAS_CHANNEL0
          if(SN76489.IntermediatePos[0]!=NO_ANTIALIAS)
          {
            SN76489.IntermediatePos[0]=NO_ANTIALIAS;
            SN76489.Channels[0]=PSGVolumeValues[SN76489.Registers[1]]*SN76489.ToneFreqPos[0];
          }
#endif
          if (SN76489.ToneFreqVals[0]<=0)
          {
            /* If it gets below 0... */
#ifndef ANTIALIAS_CHANNEL0
            SN76489.Channels[0]=PSGVolumeValues[SN76489.Registers[1]]*SN76489.ToneFreqPos[0];
#else
            SN76489.IntermediatePos[0]=(
              PSGVolumeValues[SN76489.Registers[1]]*(
                // fractional position here
                SN76489.ToneFreqPos[0] * (
                  (SN76489.NumClocksForSample<<FIXED_POINT_FRACTION_BITS) -
                  SN76489.Clock +
                  ((SN76489.ToneFreqVals[0]+SN76489.ToneFreqVals[0])<<FIXED_POINT_FRACTION_BITS)
                )
              )
            );
            SN76489.Channels[0]=SN76489.IntermediatePos[0]=dv(SN76489.IntermediatePos[0],((SN76489.NumClocksForSample<<FIXED_POINT_FRACTION_BITS) + SN76489.Clock));
#endif
            SN76489.ToneFreqPos[0]=-SN76489.ToneFreqPos[0]; /* Flip the flip-flop */
            while(SN76489.ToneFreqVals[0]<=0) SN76489.ToneFreqVals[0]+=SN76489.Registers[0]; // increment the counter back past 0
          }
        } else SN76489.Channels[0]=PSGVolumeValues[SN76489.Registers[1]];


        if (SN76489.Registers[2]>PSG_CUTOFF)
        {
          SN76489.ToneFreqVals[1]-=SN76489.NumClocksForSample;
#ifdef ANTIALIAS_CHANNEL1
          if(SN76489.IntermediatePos[1]!=NO_ANTIALIAS)
          {
            SN76489.IntermediatePos[1]=NO_ANTIALIAS;
            SN76489.Channels[1]=PSGVolumeValues[SN76489.Registers[3]]*SN76489.ToneFreqPos[1];
          }
#endif
          if (SN76489.ToneFreqVals[1]<=0)
          {
#ifndef ANTIALIAS_CHANNEL1
            SN76489.Channels[1]=PSGVolumeValues[SN76489.Registers[3]]*SN76489.ToneFreqPos[1];
#else
            SN76489.IntermediatePos[1]=(
              PSGVolumeValues[SN76489.Registers[3]]*(
                // fractional position here
                SN76489.ToneFreqPos[1] * (
                  (SN76489.NumClocksForSample<<FIXED_POINT_FRACTION_BITS) -
                  SN76489.Clock +
                  ((SN76489.ToneFreqVals[1]+SN76489.ToneFreqVals[1])<<FIXED_POINT_FRACTION_BITS)
                )
              )
            );
            SN76489.Channels[1]=SN76489.IntermediatePos[1]=dv(SN76489.IntermediatePos[1],((SN76489.NumClocksForSample<<FIXED_POINT_FRACTION_BITS) + SN76489.Clock));
#endif
            SN76489.ToneFreqPos[1]=-SN76489.ToneFreqPos[1]; /* Flip the flip-flop */
            while(SN76489.ToneFreqVals[1]<=0) SN76489.ToneFreqVals[1]+=SN76489.Registers[2]; // increment the counter back past 0
          }
        } else SN76489.Channels[1]=PSGVolumeValues[SN76489.Registers[3]];

        if (SN76489.Registers[4]>PSG_CUTOFF)
        {
          SN76489.ToneFreqVals[2]-=SN76489.NumClocksForSample;
#ifdef ANTIALIAS_CHANNEL2
          if(SN76489.IntermediatePos[2]!=NO_ANTIALIAS)
          {
            SN76489.IntermediatePos[2]=NO_ANTIALIAS;
            SN76489.Channels[2]=PSGVolumeValues[SN76489.Registers[5]]*SN76489.ToneFreqPos[2];
          }
#endif
          if (SN76489.ToneFreqVals[2]<=0)
          {
#ifndef ANTIALIAS_CHANNEL2
            SN76489.Channels[2]=PSGVolumeValues[SN76489.Registers[5]]*SN76489.ToneFreqPos[2];
#else
            SN76489.IntermediatePos[2]=(
              PSGVolumeValues[SN76489.Registers[5]]*(
                // fractional position here
                SN76489.ToneFreqPos[2] * (
                  (SN76489.NumClocksForSample<<FIXED_POINT_FRACTION_BITS) -
                  SN76489.Clock +
                  ((SN76489.ToneFreqVals[2]+SN76489.ToneFreqVals[2])<<FIXED_POINT_FRACTION_BITS)
                )
              )
            );
            SN76489.Channels[2]=SN76489.IntermediatePos[2]=dv(SN76489.IntermediatePos[2],((SN76489.NumClocksForSample<<FIXED_POINT_FRACTION_BITS) + SN76489.Clock));
#endif
            SN76489.ToneFreqPos[2]=-SN76489.ToneFreqPos[2]; /* Flip the flip-flop */
            if (SN76489.NoiseFreq==0x80)
            { 
              // if noise is matching tone2
              SN76489.ToneFreqPos[3]=SN76489.ToneFreqPos[2]<<1; // signal a flip
            }
            while(SN76489.ToneFreqVals[2]<=0) SN76489.ToneFreqVals[2]+=SN76489.Registers[4]; // increment the counter back past 0
          }
        } else SN76489.Channels[2]=PSGVolumeValues[SN76489.Registers[5]];

        // if noise is not matching tone2
        if (SN76489.NoiseFreq!=0x80)
        {
          // handle noise channel frequency counter
          SN76489.ToneFreqVals[3]-=SN76489.NumClocksForSample;
          if (SN76489.ToneFreqVals[3]<=0)
          {
            SN76489.ToneFreqPos[3]=-SN76489.ToneFreqPos[3];
            /*while(SN76489.ToneFreqVals[3]<=0) */SN76489.ToneFreqVals[3]+=SN76489.NoiseFreq; // shouldn't be necessary to loop on this one
            if (SN76489.ToneFreqPos[3]==1) 
            {
              ++SN76489.ToneFreqPos[3]; // signal a flip with a 2
            }
          }
        }
        // if flip has been signalled
        if(SN76489.ToneFreqPos[3]==2)
        {
          int Feedback;
          SN76489.ToneFreqPos[3]=1; // unset signal
          if (SN76489.Registers[6]&0x4) // White noise
          {
            switch (SN76489.NoiseFeedback)
            {
              // optimise for common cases
              case 0x0003: // SN76489 discrete chip
                Feedback=((SN76489.NoiseShiftRegister) ^ (SN76489.NoiseShiftRegister >> 1)) & 1;
                break;
              case 0x0009: // Sega VDP
                Feedback=((SN76489.NoiseShiftRegister) ^ (SN76489.NoiseShiftRegister >> 3)) & 1;
                break;
              default:
                // mask and fold bits in
                Feedback=SN76489.NoiseShiftRegister & SN76489.NoiseFeedback;
                Feedback ^= Feedback << 16;
                Feedback ^= Feedback <<  8;
                Feedback ^= Feedback <<  4;
                Feedback ^= Feedback <<  2;
                Feedback ^= Feedback <<  1;
                break;
            }
          }
          else
          {
            // periodic noise
            Feedback=SN76489.NoiseShiftRegister&1;
          }
          SN76489.NoiseShiftRegister=(SN76489.NoiseShiftRegister>>1) | (Feedback<<SN76489.NoiseSRWidth);
          if(SN76489.NoiseShiftRegister&1)
            SN76489.Channels[3]=PSGVolumeValues[SN76489.Registers[7]]<<1;
          else
            SN76489.Channels[3]=0;
        }

    }
}
