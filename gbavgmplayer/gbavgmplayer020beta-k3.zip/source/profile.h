#include "pin8gba.h"
// Profiling by changing screen colours
#define PROFILE
#ifdef PROFILE
#  define PROFILE_WAIT_Y(y) do {} while(LCD_Y != (y))
#  define PROFILE_COLOR(r,g,b) (PALRAM[0] = RGB((r),(g),(b)))
#else
#  define PROFILE_WAIT_Y(y) ((void)0)
#  define PROFILE_COLOR(r,g,b) ((void)0)
#endif
