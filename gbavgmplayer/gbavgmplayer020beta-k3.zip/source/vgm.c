#include <string.h>
#include "vgm.h"
#include "sn76489.h"
#include "directsound_settings.h"
#include "profile.h"

// VGM data bytes
// 0x30-0x50: one operand
#define VGM_GGST        0x4f
#define VGM_PSG         0x50
// 0x51-0x5f: two operands
#define VGM_YM2413      0x51
#define VGM_YM2612_0    0x52
#define VGM_YM2612_1    0x53
#define VGM_YM2151      0x54
// 0x60-0x9f: VGM housekeeping and pauses, variable operands
#define VGM_PAUSE_WORD  0x61
#define VGM_PAUSE_60TH  0x62
#define VGM_PAUSE_50TH  0x63
#define VGM_END         0x66
#define VGM_DATA_BLOCK  0x67
// Also 0x7n = pause n+1
// Also 0x8n = pause n+1, YM2612 output port 0 address 2A data from data bank
// 0xa0-0xbf: two operands
// unused
// 0xc0-0xdf: three operands
// unused
// 0xe0-0xff: four operands
#define VGM_DATA_SEEK   0xe0

// VGM file header
struct TVGMHeader {
	char	VGMIdent[4];	// "Vgm "
	long	EoFOffset;		// relative offset (from this point, 0x04) of the end of file
	long	Version;		// 0x00000101 for 1.01
	long	PSGClock;		// typically 3579545, 0 for no PSG
	long	FMClock;		// typically 3579545, 0 for no FM
	long	GD3Offset;		// relative offset (from this point, 0x14) of the Gd3 tag, 0 if not present
	long	TotalLength;	// in samples
	long	LoopOffset;		// relative again (to 0x1c), 0 if no loop
	long	LoopLength;		// in samples, 0 if no loop
	// Below here VGM 1.01+
	long	RecordingRate;	// in Hz, for speed-changing, 0 for no changing
	// Below here VGM 1.10+
	short PSGFeedback; // noise LFSR feedback bit pattern ;
	char  PSGSRWidth; // noise shift register width
	char reserved;
	long  YM2612Clock;
	long  YM2151Clock;
	// Below here VGM 1.50+
	long  DataOffset;
} VGMHeader;

#define EOFDELTA  0x04
#define GD3DELTA  0x14
#define LOOPDELTA 0x1c
#define DATADELTA 0x34

#define VGM_DATA_OFFSET 0x40

#define LEN60TH 735
#define LEN50TH 882

SN76489_Context PSG;

int file_time_count; // how much time is available to render, in 44100Hz samples

char *vgmfile;
int loopcount;
signed int loop_limit;

#ifndef WIN32
extern int dv(int, int) __attribute__((long_call));
#else
extern int dv(int, int);
#endif

// initialise decoder, prepare to start a new track
void vgm_init(char *source) {
  // read header
  memcpy(&VGMHeader,source,sizeof(VGMHeader));
  // initialise stuff
  SN76489_Init(VGMHeader.PSGClock,SAMPLING_RATE,VGMHeader.PSGFeedback,VGMHeader.PSGSRWidth);
  file_time_count=0;
  loopcount=0;
  // make header offsets absolute in the ROM
  if(VGMHeader.EoFOffset) VGMHeader.EoFOffset +=EOFDELTA +(int)source;
  if(VGMHeader.LoopOffset)VGMHeader.LoopOffset+=LOOPDELTA+(int)source;
  if(VGMHeader.GD3Offset) VGMHeader.GD3Offset +=GD3DELTA +(int)source;
  // seek to start
  if (VGMHeader.Version >= 0x0150)
    vgmfile = source + VGMHeader.DataOffset + DATADELTA;
  else
    vgmfile=source+VGM_DATA_OFFSET;
}

char *vgm_decode(signed char *dest,int num_samples,int speed) {
  char c;
  while(num_samples) { // while the buffer isn't full
    // output samples if the VGM data is still registering a pause
    if(file_time_count) {
      PROFILE_COLOR(31,0,0);
      int sample_count=dv(file_time_count*SAMPLING_RATE,44100); // how many output samples, rounded down
      // can't render more than there is left in the buffer
      // decrease file_time_count appropriately
      if(sample_count>num_samples) {
        sample_count=num_samples;
        file_time_count-=dv(sample_count*44100,SAMPLING_RATE);
      } else {
        // pause length was smaller than the buffer size
        file_time_count=0;
      }

      // render to the buffer
      SN76489_Update(dest, sample_count);
      // move pointer on
      dest+=sample_count;
      // decrement the sample counter by the number rendered
      num_samples-=sample_count;
    }

    if(num_samples==0) return 0;

    PROFILE_COLOR(31,31,0);
    // get data from file
    c=*vgmfile++;
    switch(c) {
    case VGM_PSG:
      // write, 1 bytes
      SN76489_Write(*vgmfile++);
      break;
    case VGM_PAUSE_WORD:
      // add low byte, high byte
      file_time_count+=(*vgmfile++)>>speed;
      file_time_count+=((*vgmfile++)<<8)>>speed;
      break;
    case VGM_PAUSE_60TH:
      file_time_count+=LEN60TH>>speed;
      break;
    case VGM_PAUSE_50TH:
      file_time_count+=LEN50TH>>speed;
      break;
    case VGM_END:
      if(
        (VGMHeader.LoopOffset) &&     // looped section exists
        (
          (++loopcount<loop_limit) || // loop count hasn't exceeded limit yet
          (loop_limit<0)              // or limit is infinity
        )
      ) vgmfile=(char *)VGMHeader.LoopOffset; // play looped section again
      else {
        // next track wanted, so set pointer to somewhere past the end of the file
        // VGMHeader.EoFOffset is not reliable
        return (char *)0xffffffff;
      }
      break;
    case 0x70: case 0x71: case 0x72: case 0x73:
    case 0x74: case 0x75: case 0x76: case 0x77:
    case 0x78: case 0x79: case 0x7a: case 0x7b:
    case 0x7c: case 0x7d: case 0x7e: case 0x7f:
      file_time_count+=(c & 0xf)+1;
      break;
    case VGM_DATA_BLOCK:
      // skip data blocks
      {
        long size = 0;
        vgmfile+=2; // skip 0x66, block type
        size|=*vgmfile++ <<  0;
        size|=*vgmfile++ <<  8;
        size|=*vgmfile++ << 16;
        size|=*vgmfile++ << 24;
        vgmfile+=size;
      }
      break;
    default:
      // forward compatibility handling
      switch(c >> 4)
      {
        case 0x3:
        case 0x4:
          // one operand
          // VGM_GGST ignored
          vgmfile++;
          break;
        case 0x5:
        case 0xa:
        case 0xb:
          // two operands (except 0x50 already handled above, VGM_PSG)
          // VGM_YM* ignored
          vgmfile+=2;
          break;
        case 0xc:
        case 0xd:
          // three operands
          vgmfile+=3;
          break;
        case 0xe:
        case 0xf:
          // four operands
          // VGM_DATA_SEEK ignored
          vgmfile+=4;
          break;
      }
      break;
    }
  }

  return vgmfile; // return pointer to next data
}

char* vgm_gd3_location(void) {
  return (char *)VGMHeader.GD3Offset;
}

void setlooplimit(signed int count) {
  loop_limit=count;
}

unsigned long vgm_total_length(void) {
  return VGMHeader.TotalLength;
}

unsigned long vgm_loop_length(void) {
  return VGMHeader.LoopLength;
}
