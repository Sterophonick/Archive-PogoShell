// vgm routines

void vgm_init(char *source); // initialise decoder, start new track
char *vgm_decode(signed char *dest,int num_samples,int speed); // decode into buffer
char *vgm_gd3_location(void); // returns the GD3 location
void setlooplimit(signed int count);
unsigned long vgm_total_length(void);
unsigned long vgm_loop_length(void);
