// Settngs for Direct Sound channel to get correct output
// see http://www.pineight.com/gba/samplerates/
// good periods:
// 532 627 798 836 924 1254 1463 1596 2508 2926
// Longer = less CPU use, lower sampling rate
// Problems below 924 currently

#define TIMER_PERIOD (836) // how often to trigger the DMA
#define BUFFER_SIZE ROUNDPOS(280896/TIMER_PERIOD)
#define SAMPLING_RATE ROUNDPOS(16777216/TIMER_PERIOD)

#define ROUNDPOS(x) ((int)(x+0.5))

