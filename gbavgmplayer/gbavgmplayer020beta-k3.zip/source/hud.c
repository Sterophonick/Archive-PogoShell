#include <stdlib.h>
#include "string.h"
#include "pin8gba.h"
#include "vgm.h"

extern const char _8x16_fnt_lz[];
extern const unsigned int _8x16_fnt_lz_len;

extern u32 fracumul(u32, u32) __attribute__((long_call));
extern s32 dv(s32, s32) __attribute__((long_call));

inline void LZ77UnCompVRAM(void *source, void *dest) {
asm("mov r0, %0\n"
"mov r1, %1\n"
"swi 0x12\n"
:
:"r" (source), "r" (dest)
:"r0", "r1" );
}

/* upcvt_4bit() ************************
   Converts a 1-bit font to GBA 4-bit format.
*/
void upcvt_4bit(void *dst, const u8 *src, size_t len)
{
  u32 *out = dst;

  for(; len > 0; len--)
  {
    u32 dst_bits = 0;
    u32 src_bits = *src++;
    u32 x;

    for(x = 0; x < 8; x++)
    {
      dst_bits <<= 4;
      dst_bits |= src_bits & 1;
      src_bits >>= 1;
    }
    *out++ = dst_bits;
  }
}

// length of display lines
#define MAX_LENGTH 28

struct HUD_CLOCK
{
  unsigned int cycles;
  unsigned char trackno[4];
  unsigned char trackcount[4];
  unsigned char clock[4];
} hud_clock;


void hud_wline(unsigned int y, const char *s)
{
  unsigned short *dst = MAP[31][y * 2] + 1;
  unsigned int wid_left;

  for(wid_left = 28; wid_left > 0 && *s; wid_left--)
  {
    unsigned char c0 = *s++;

    dst[0] = c0 << 1;
    dst[32] = (c0 << 1) | 1;
    ++dst;
  }
  for(; wid_left > 0; wid_left--, dst++)
  {
    dst[0] = 0x0040;
    dst[32] = 0x0041;
  }
}

void hud_cls(int trackcount)
{
  unsigned int i;

  for(i = 0; i < 32*20; i++)
    MAP[31][0][i] = 0x0040;

  hud_wline(1, " GBA VGM Player \xa9""2006 Maxim"); // hex escaping (c)2006 as \xa92006 was problematic
  hud_wline(2, "  http://www.smspower.org");
//  hud_wline(3, (char*)trackcount);

  // BCD convert track count
  i = dv(trackcount, 10);
  hud_clock.trackcount[3] = trackcount - i * 10 + '0';
  trackcount = i;
  i = dv(trackcount, 10);
  hud_clock.trackcount[2] = trackcount - i * 10 + '0';
  trackcount = i;
  i = dv(trackcount, 10);
  hud_clock.trackcount[1] = trackcount - i * 10 + '0';
  trackcount = i;
  i = dv(trackcount, 10);
  hud_clock.trackcount[0] = trackcount - i * 10 + '0';
}

void hud_init(int trackcount)
{
  PALRAM[0] = RGB(31, 31, 31); // white background
  PALRAM[1] = RGB(0, 0, 0);
  LCDMODE = 0;
  LZ77UnCompVRAM(_8x16_fnt_lz,VRAM);
  //upcvt_4bit(VRAM, VRAM+0x160*8*16/2, 0x100*8*16/8);

  BGCTRL[2] = BGCTRL_NAME(31) | BGCTRL_PAT(0);

  hud_cls(trackcount);

  while(LCD_Y < 160) {}
  LCDMODE = 0 | LCDMODE_BG2;
}



/* base 10, 10, 6, 10 conversion */
unsigned int hud_bcd[] =
{
  600, 60, 10, 1
};


#undef BCD_LOOP
#define BCD_LOOP(b) if(src >= fac << b) { src -= fac << b; c += 1 << b; }

void decimal_time(char *dst, unsigned int src)
{
  unsigned int i;

  for(i = 0; i < 4; i++)
    {
      unsigned int fac = hud_bcd[i];
      char c = '0';

      BCD_LOOP(3);
      BCD_LOOP(2);
      BCD_LOOP(1);
      BCD_LOOP(0);
      *dst++ = c;
    }
}

void hud_frame(int locked, unsigned int t, signed int loopcount)
{
  char line1[ MAX_LENGTH + 1 ] = "Time   :  /  :           \x0a\x0b ";
  char line2[ MAX_LENGTH + 1 ] = "Track     /                 ";
  /* Display:
   * ****************************
   * Time mm:ss/mm:ss         LLn
   * Track tttt/tttt    P  L  SS
   * ****************************
   * L = lock
   * P = pause
   * SS = shuffle
   * tttt = track number
   * mm:ss = time
   * LLn = loop
   */
  char time_bcd[ 4 ];
  char length_bcd[ 4 ];

  unsigned long length;
  int i;

  /* t is how many frames it's run for
     GBA runs at ~59.73Hz
     so time in seconds is t/59.73
     1/59.73 * 2^32 = 71906367
  */
  t = fracumul(t, 71906367);
  if(t > 5999)
    t = 5999; /* 99 minutes 59 seconds */
  decimal_time(time_bcd, t);

  /* Lock */
  if (locked & JOY_SELECT)
    line2[22] = 12;

  /* Pause */
  if (locked & JOY_START)
    line2[19] = 9;

  /* Track number */
  line2[6] = hud_clock.trackno[0];
  line2[7] = hud_clock.trackno[1];
  line2[8] = hud_clock.trackno[2];
  line2[9] = hud_clock.trackno[3];
  line2[11] = hud_clock.trackcount[0];
  line2[12] = hud_clock.trackcount[1];
  line2[13] = hud_clock.trackcount[2];
  line2[14] = hud_clock.trackcount[3];

  /* Shuffle */
  if ( locked & 0x0800 )
  {
    line2[25] = 13;
    line2[26] = 14;
  }

  /* Time */
  line1[5] = time_bcd[0];
  line1[6] = time_bcd[1];
  line1[8] = time_bcd[2];
  line1[9] = time_bcd[3];
  if ( loopcount > 0 )
  {
    length = vgm_total_length();
    for ( i = 1; i < loopcount; ++i )
      length += vgm_loop_length();
    length = fracumul( length, 97392 ); /* equivalent to length /= 44100 */
    decimal_time( length_bcd, length );
    line1[11] = length_bcd[0];
    line1[12] = length_bcd[1];
    line1[14] = length_bcd[2];
    line1[15] = length_bcd[3];
  } else {
    line1[10] = ' ';
    line1[13] = ' ';
  }

  /* Loop count */
  line1[27] = loopcount+'0';

  hud_wline(8, line1);
  hud_wline(9, line2);
}

char *getgd3string(char *buffer,int length,char *src) {
  // read in values
  unsigned short c=1; // non-zero

  while(length>0) {
    c=*src++;
    c+=(*src++)<<8;
    if(c>0x15f) c='?';
    *buffer++=(char)(c & 0xff);
    --length;
    if(c==0) break;
  }
  *buffer++='\0'; // terminate string if it was cut off
  // eat extra chars up to the terminating \0\0
  while(c!=0) {
    c=*src++;
    c+=(*src++)<<8;
  }
  return src;
}

void hud_new_song(char *GD3, unsigned int trackno)
{
  int upper;
  char textline[MAX_LENGTH+1];

  memcpy(textline,GD3,4);
  textline[4]='\0';
  if(strcmp(textline,"Gd3 ")==0) { // we have a GD3 tag
    GD3+=12;

    GD3=getgd3string(textline,MAX_LENGTH,GD3); // track name
    hud_wline(4, textline);
    GD3=getgd3string(NULL,0,GD3); // skip japanese
    GD3=getgd3string(textline,MAX_LENGTH,GD3); // game name
    hud_wline(5, textline);
    GD3=getgd3string(NULL,0,GD3);
    GD3=getgd3string(textline,MAX_LENGTH,GD3); // system name
    hud_wline(6, textline);
    GD3=getgd3string(NULL,0,GD3);
    GD3=getgd3string(textline,MAX_LENGTH,GD3); // author
    hud_wline(7, textline);

  }

  hud_clock.cycles = 0;

  // Reset clock
  for(upper = 0; upper < 4; upper++)
    hud_clock.clock[upper] = 0;

  // BCD convert track number
  upper = dv(trackno, 10);
  hud_clock.trackno[3] = trackno - upper * 10 + '0';
  trackno = upper;
  upper = dv(trackno, 10);
  hud_clock.trackno[2] = trackno - upper * 10 + '0';
  trackno = upper;
  upper = dv(trackno, 10);
  hud_clock.trackno[1] = trackno - upper * 10 + '0';
  trackno = upper;
  upper = dv(trackno, 10);
  hud_clock.trackno[0] = trackno - upper * 10 + '0';
}

