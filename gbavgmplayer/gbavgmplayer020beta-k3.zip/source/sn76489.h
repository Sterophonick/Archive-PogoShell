#ifndef _SN76489_H_
#define _SN76489_H_

//#define CODE_IN_IWRAM __attribute__ ((section (".iwram"), long_call))

#ifndef INT32
#define INT32 signed long
#endif
#ifndef UINT16
#define UINT16 unsigned short
#endif
#ifndef INT16
#define INT16 signed short
#endif
#ifndef INT8
#define INT8 signed char
#endif
#ifndef uint8
#define uint8 signed char
#endif

typedef struct
{
    /* expose this for inspection/modification for channel muting */
    int BoostNoise;
    int VolumeArray;

    /* Variables */
    int Clock;
    int dClock;

    int NumClocksForSample;
    int WhiteNoiseFeedback;

    /* PSG registers: */
    int Registers[8];        /* Tone, vol x4 */
    int LatchedRegister;
    int NoiseShiftRegister;
    int NoiseFreq;            /* Noise channel signal generator frequency */

    /* Output calculation variables */
    int ToneFreqVals[4];      /* Frequency register values (counters) */
    int ToneFreqPos[4];       /* Frequency channel flip-flops */
    int Channels[4];          /* Value of each channel, before stereo is applied */

    int IntermediatePos[4];   /* for antialiasing */
    
    int NoiseSRWidth;
    int NoiseFeedback;
} SN76489_Context;

/* Function prototypes */
void SN76489_Init(int PSGClockValue, int SamplingRate, int PSGFeedback, int PSGSRWidth);
void SN76489_Reset(void);
void SN76489_Write(int data);
void SN76489_Update(signed char *buffer, int length);

#endif /* _SN76489_H_ */

