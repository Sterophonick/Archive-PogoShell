/* vgmplayer.c
   Plays VGM audio through Game Boy Advance hardware.
   Based on gsmplay.c Copyright 2004 by Damian Yerrick.
   Modifications by Maxim
*/

#include <stdlib.h>
#include <string.h>
#include "pin8gba.h"
#include "vgm.h"
#include "gbfs.h"
#include "directsound_settings.h"
#include "reset.h"
#include "profile.h"
#include "minilzo.107/minilzo.h"

void isr(void);

void init_sound(void){
  TIMER[0].control = 0;
  // turn on sound circuit
  SETSNDRES(1);
  SNDSTAT = SNDSTAT_ENABLE;
  DSOUNDCTRL = 0x0b0e;
  TIMER[0].count = 0x10000 - TIMER_PERIOD;
  TIMER[0].control = TIMER_16MHZ | TIMER_ENABLE;
}

static void dsound_switch_buffers(const void *src){
  DMA[1].control = 0;

  /* no-op to let DMA registers catch up */
  asm volatile ("eor r0, r0; eor r0, r0" ::: "r0");

  DMA[1].src = src;
  DMA[1].dst = (void *)0x040000a0; /* write to FIFO A address */
  DMA[1].count = 1;
  DMA[1].control = DMA_DSTUNCH | DMA_SRCINC | DMA_REPEAT | DMA_U32 |
                   DMA_SPECIAL | DMA_ENABLE;
}

unsigned int rand_seed = 0x600D5EED;

unsigned short math_rand (unsigned short max) {
	unsigned int rnd,div;
	if(max>0x7FFF) max=0x7FFF;
	div=0x8000/(max+1);
	rand_seed=rand_seed*1103515245+12345;
	rnd=(rand_seed>>16)&0x7FFF;
	rnd/=div;
	rnd&=0x7fff;
	while(rnd>max) rnd>>=1;
	return rnd;
}


void wait4vbl(void){
  asm volatile("mov r2, #0; swi 0x05" ::: "r0", "r1", "r2", "r3");
}

const GBFS_FILE *fs;      // Pointer to GBFS
const char *src;          // Pointer to data
unsigned int src_len;     // Length of data
int pogoshell;            // boolean true if in Pogoshell
int no_gbfs;

//signed short input_buffer[BUFFER_SIZE]; // input buffer - samples output by decoder (16-bit signed)
signed char double_buffers[2][BUFFER_SIZE] __attribute__ ((aligned (4))); // two output buffers (8-bit signed samples)

char decompressed_buffer[0] IN_EWRAM; // actually 200+KB but I set it to 0 to avoid allocating 200KB of blank space in the ROM to initialise it

// bits 0x3ff are for input
#define CMD_START_SONG 0x0400
#define ST_SHUFFLE 0x0800
#define ST_FAST 0x1000

void hud_init(int trackcount);
void hud_new_song(const char *name, unsigned int trackno);
void hud_frame(int locked, unsigned int t,signed int loopcount);
void hud_wline(unsigned int y, const char *s);

void streaming_run(void){
  const char *src_pos = NULL; // pointer to input data
  const char *src_end = NULL; // pointer to end of input data
  unsigned int cur_buffer = 0; // output buffer number
  unsigned short last_joy = 0x3ff; // last input
  unsigned int cur_song = (unsigned int)(-1); // which song this is
  unsigned int numframes = 0; // how many frames we've played in this song
  signed int loopcount = 2; // how many times to play the looped section
  int trackcount; // how many VGM files there are
  // Note:
  // *src_pos starts equal to *src_end which triggers a "next track" command
  // This increments cur_song to 0 and triggers a "start track" command", and thus makes it play the first track
  // This behaviour is dependent on the ordering of the code.
  int state = 0; // locked, paused, shuffle states
  int speed = 0; // how many bits to shift delays by

  trackcount = no_gbfs ? 1 : gbfs_count_objs(fs);

  setlooplimit(loopcount);

  while(1){
    // get input, mask to low 10 bits and reverse logic to active high
    unsigned short j = (JOY & 0x3ff) ^ 0x3ff;
    // mask off buttons that were pressed last time, except for A and B buttons
    unsigned short cmd = j & (~last_joy);
    // pointer for writing
    signed char *dst_pos = double_buffers[cur_buffer];

    last_joy = j; // save currently pressed keys

    if(cmd)rand_seed^=numframes; // seed random number with input

    // Toggle lock on Select
    if(cmd & JOY_SELECT) 
    {
      if (LCDMODE & LCDMODE_BLANK) // !(state & JOY_SELECT))
      {
        // unlock
        state^=JOY_SELECT;
        LCDMODE^=LCDMODE_BLANK;
      } else if (state & JOY_SELECT)
      {
        // blank
        LCDMODE^=LCDMODE_BLANK;
      }
      else
      {
        // lock
        state^=JOY_SELECT;
      }
    }

    // nullify any other button presses if locked
    if(state & JOY_SELECT) {
      cmd=0;
      j=0;
    }

    // A+B+Start+Select = exit to Pogoshell (or cart menu)
    //if((j & (JOY_SELECT | JOY_START | JOY_A | JOY_B)) == (JOY_SELECT | JOY_START | JOY_A | JOY_B))
	if (cmd & JOY_L)
      reset_gba();

    // Toggle pause on Start
    if(cmd & JOY_START) state^=JOY_START;

    // if we've got to the end of the data then seek to the next track
    if(src_pos >= src_end) {
      // non-pogo: seek to next track
      cmd|=JOY_RIGHT;
    }

    // Next track
    if(cmd & JOY_RIGHT) {
      int amt=1;
      if(j & JOY_B) amt=100;
      if(j & JOY_A) amt=10;
      if(state & ST_SHUFFLE) amt=math_rand(trackcount-2)+1;
      while(amt>trackcount) amt-=trackcount;
      if(cur_song+amt>=trackcount) cur_song=cur_song+amt-trackcount;
      else cur_song+=amt;
      cmd|=CMD_START_SONG;
    }

    // Previous track
    if(cmd & JOY_LEFT) {
      int amt=1;
      if(j & JOY_B) amt=100;
      if(j & JOY_A) amt=10;
      if(state & ST_SHUFFLE) amt=math_rand(trackcount-2)+1;
      while(amt>trackcount) amt-=trackcount;
      if(amt>cur_song) cur_song=trackcount+cur_song-amt;
      else cur_song-=amt;
      cmd|=CMD_START_SONG;
    }

    // shuffle A+B
    if(((cmd & JOY_A) && (j & JOY_B) ) ||
      ( (cmd & JOY_B) && (j & JOY_A) ))
		state^=ST_SHUFFLE;

    // fast-forward R
    if(j & JOY_R) speed=3;
    else speed=0;

    // loop count U/D
    // A bit hacky: the infinity character is index '0'-17
    if(cmd & JOY_UP) {
      if(loopcount<9) ++loopcount;
      if(loopcount<1) loopcount=1;
      setlooplimit(loopcount);
    }
    if(cmd & JOY_DOWN) {
      if(loopcount>0) --loopcount;
      if(loopcount==0) loopcount=-33;
      setlooplimit(loopcount);
    }

    // Start song needed
    if(cmd & CMD_START_SONG){
      // turn off DMA to stop clicks
      DMA[1].control = 0;

      if (no_gbfs) {
        src=(*(u8**)0x0203FBFC);
        src_len=(*(u32*)0x0203FBF8);
      } else {
        src=gbfs_get_nth_obj(fs,cur_song,NULL,&src_len); // get data info
      }

      // assume LZO if no VGM header found
      if ( memcmp( src, "Vgm ", 4 ) != 0 )
      {
        int r;
        // decompress
        hud_wline(0,"Decompressing LZO...");
        r = lzo1x_decompress( src, src_len, decompressed_buffer, &src_len, NULL );
        if ( r < 0 || src_len > 256*1024 )
        {
          hud_wline(0,"LZO error");
          PALRAM[0] = RGB(31, 0, 0);
          while(1){}
        }
        hud_wline(0,"");
        src = decompressed_buffer;
      }
      src_pos=src;
      src_end=src+src_len;

      if ( memcmp( src, "Vgm ", 4 ) != 0 )
      {
        hud_wline(0,"Not a VGM file");
        PALRAM[0] = RGB(31, 0, 0);
        while(1) {}
      }

      vgm_init(src);
      hud_new_song(vgm_gd3_location(),cur_song+1); // display info
      numframes=0;
    }

    // Wait for line 0 if profiling
//    PROFILE_WAIT_Y(0);
    // turned off because it wastes time and makes the profiling useless...

    // if paused:
    if(state & JOY_START)
    {
      for(j=BUFFER_SIZE/4;j>0;j--){ // fill the output buffer with the last sample (unrolled 4x)
         *dst_pos++ = 0;
         *dst_pos++ = 0;
         *dst_pos++ = 0;
         *dst_pos++ = 0;
      }
    }
    else
    {
      // not paused:
      // if we're not at the end of the data yet, decode into the buffer
      if(src_pos<src_end) {
        PROFILE_COLOR(31,0,0); // red for decoding
        src_pos=vgm_decode(dst_pos,BUFFER_SIZE,speed);
        PROFILE_COLOR(0,31,0); // green for copying (not done any more, yay!)
      }
      else
      {
        hud_wline(0,"Past end of track, error?");
      }
      numframes+=(1<<speed);
    }

    // grey for wait for VBlank
    PROFILE_COLOR(27, 27, 27);
    // Trigger DMA buffer output in the VBlank
    wait4vbl();
    dsound_switch_buffers(double_buffers[cur_buffer]);

    // Update UI
    PROFILE_COLOR(31,0,31); // purple for GUI update
    hud_frame(state, numframes, loopcount);
    PROFILE_COLOR(0,0,31); // blue for end

    // Swap output buffer so DMA can do its stuff safely
    cur_buffer ^= 1;
  }
}


int main(void)
{
	u8 *temp = *(u8 **)0x0203fbfc;
  const char magic[] = "GBFS\r\n\x1a\nPinEight";

  /* enable interrupts */
  SET_MASTER_ISR(isr);
  LCDSTAT = LCDSTAT_VBLIRQ;  /* one plug to the display */
  INTMASK = INT_VBLANK | INT_TIMER(1);  /* the other to the isr */
  INTENABLE = 1;  /* and flip the switch */

  // Pogoshell support
  pogoshell=((((u32) temp) & 0xFE000000) == 0x8000000);

  no_gbfs = 0;

  hud_init(0);
  if (pogoshell) {
	fs = (GBFS_FILE *) temp;
    if(memcmp(temp, &magic[8], 8) || memcmp(temp+8, &magic[0], 8)) {
		no_gbfs = 1;
		hud_init(1);
	} else
  		hud_init(gbfs_count_objs(fs));      // init UI
    while ((JOY & 0x3ff) ^ 0x3ff);
  } else { // it's stand-alone
	// die with a red screen if no files attached
	fs = find_first_gbfs_file((u8 *)0x8000000);
	if(!fs)
	{
    	hud_wline(0,"GBFS not found");
	    PALRAM[0] = RGB(31, 0, 0);
    	while(1) {}
    }
    hud_init(gbfs_count_objs(fs));      // init UI
  }

  init_sound();    // init sound hardware

  lzo_init();

  streaming_run(); // go
  while(1) {}
}
