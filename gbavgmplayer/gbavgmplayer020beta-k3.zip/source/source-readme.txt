GBA VGM Player source
=====================

by Maxim


Compiling environment
=====================

- devkitARM
- MSYS from MinGW

Google for them, put both in your path, type make to build it.

If you want to make a new font, you'll need a tool that can output suitable
data: 4bpp 8x8-pixel 1x2-tiles. I didn't find a usable to to do that and made
my own which is not released yet. GBACrusherCL is needed to compress it.


Contacting me
=============

org.smspower@maxim

You known what to do.

