
import sys, os
from sys import argv

if __name__ == "__main__":
	d = { 'u': 0, 'd': 1, 'l': 2, 'r': 3 }
	key = 0xFEBF5FAFD7EBF5FAFD7EBF5FAFD7EBF5
	input = raw_input("Key: ")
	for f in input:
		if d.has_key(f):
			key = ((key << 2) | d[f]) % (1<<126)
		else:
			print "Invalid input:", f
			print "Valid input is a combination of u, d, l, and r"
			sys.exit(1)
	str = "$key$%032x" % key
	if len(argv) == 2 and (argv[1] == "-m" or \
						   argv[1] == "-make" or \
						   argv == "--make"):
		os.mkdir(str)
	else:
		print str
