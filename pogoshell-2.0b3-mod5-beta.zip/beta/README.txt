
To use:

Run "makefs.py pogo_<card>.gba root flashme.gba"

The simplest approach to doing this is to copy all the *.py files and
pogo_<card>.gba to your current Pogoshell directory.

Feel free to test out the built-in jpeg viewer (jpg 6 JPG in pogo.cfg) for
images up to 400x300.  Also feel free to test out the support for directories
up to 500 files long (if you do have a directory that long, be prepared for
it to take a second or two to sort).  I'm mostly concerned, though, with
savings working properly and games working.  So, that's the thing to mainly
focus on.  Private message me any results specific to the beta or put more
generic comments (feature requests, etc) in the main beta tester thread.

-- Kuwanger
