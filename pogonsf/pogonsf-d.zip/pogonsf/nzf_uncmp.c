
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdio.h>
#include <unistd.h>
#include <errno.h>
#include <lzo1x.h>

#ifndef O_BINARY
#define O_BINARY 0
#endif

int main(int argc, char *argv[])
{
    char buffer[192 * 1024], buffer2[192 * 1024 * 6 / 5], *s;
    int compressed_size;
    struct stat buf;
    int in, out, n, i;

    if (argc != 3) {
	fprintf(stderr, "Usage: %s <in.nzf> <out.nsf>\n", argv[0]);
    } else {
	in = open(argv[1], O_RDONLY | O_BINARY);

	fstat(in, &buf);
	compressed_size = buf.st_size;

	if (compressed_size == 0) {
	    fprintf(stderr, "Nothing to compress.\n");
	} else if (compressed_size > 192 * 1024) {
	    fprintf(stderr,
		    "File too big. File must be less than 205K.\n");
	} else {
	    n = compressed_size;
	    s = buffer;
	    while ((i = read(in, s, n)) > 0 && i != n) {
		s += i;
		n -= i;
	    }
	    if (i == -1) {

		switch (errno) {
		case EINTR:
		    fprintf(stderr, "EINTR\n");
		    break;
		case EAGAIN:
		    fprintf(stderr, "EAGAIN\n");
		    break;
		case EIO:
		    fprintf(stderr, "EIO\n");
		    break;
		case EISDIR:
		    fprintf(stderr, "EISDIR\n");
		    break;
		case EBADF:
		    fprintf(stderr, "EBADF\n");
		    break;
		case EINVAL:
		    fprintf(stderr, "EINVAL\n");
		    break;
		case EFAULT:
		    fprintf(stderr, "EFAULT\n");
		    break;
		default:
		    fprintf(stderr, "Unknown error\n");
		    break;
		}
	    } else {
		lzo_init();

		out =
		    open(argv[2], O_TRUNC | O_WRONLY | O_CREAT | O_BINARY,
			 0600);

		lzo1x_decompress(buffer, compressed_size, buffer2,
				 &compressed_size, NULL);
		write(out, buffer2, compressed_size);
		return 0;
	    }
	}
    }
    return 1;
}
