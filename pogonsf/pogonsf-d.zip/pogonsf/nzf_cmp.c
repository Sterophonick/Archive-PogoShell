
#include <stdio.h>
#include <stdlib.h>
#include <lzo1x.h>

#define SIZE (64*1024)

int
main(int argc, char *argv[])
{
    char            buffer[SIZE],
                    buffer2[SIZE * 2 * 6 / 5],
                    workspace[448 * 1024];
    int             compressed_size;
    FILE           *in,
                   *out;

    if (argc != 3) {
	fprintf(stderr, "Usage: %s <in.nsf> <out.nzf>\n", argv[0]);
	return 1;
    } else {
	in = fopen(argv[1], "rb");
	if (!in) {
	    fprintf(stderr, "Error opening file %s.\n", argv[1]);
	    fclose(in);
	    return 2;
	}

	if (fseek(in, 0, SEEK_END) == EOF) {
	    fprintf(stderr, "Error seeking in file %s.\n", argv[1]);
	    fclose(in);
	    return 3;
	}

	compressed_size = ftell(in);

	if (compressed_size == -1) {
	    fprintf(stderr, "Unable to obtain file position.\n");
	    fclose(in);
	    return 4;
	} else if (compressed_size == 0) {
	    fprintf(stderr, "Nothing to compress.\n");
	    fclose(in);
	    return 5;
	} else if (compressed_size > SIZE) {
	    fprintf(stderr,
		    "File too big. File must be less than 205K.\n");
	    fclose(in);
	    return 6;
	} else {
	    if (fseek(in, 0, SEEK_SET) == EOF) {
		fprintf(stderr, "Error seeking in file %s.\n", argv[1]);
		fclose(in);
		return 7;
	    }

	    if (fread(buffer, 1, compressed_size, in) != compressed_size) {
		fprintf(stderr, "Error reading file %s.\n", argv[1]);
		fclose(in);
		return 8;
	    }
	    fclose(in);

	    lzo_init();
	    lzo1x_999_compress(buffer, compressed_size, buffer2,
			       &compressed_size, workspace);

	    out = fopen(argv[2], "wb");
	    if (!out) {
		fprintf(stderr, "Error opening file %s.\n", argv[2]);
		fclose(in);
		return 9;
	    }

	    if (fwrite(buffer2, 1, compressed_size, out) !=
		compressed_size) {
		fprintf(stderr, "Error writing file %s.\n", argv[1]);
		fclose(out);
		return 10;
	    }

	    fclose(out);
	    return 0;
	}
    }
    return 1;
}
