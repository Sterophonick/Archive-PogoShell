	IMPORT |wram_globals0$$Base|
	IMPORT nes_reset
	IMPORT agb_vbl
	IMPORT cpustate
	IMPORT rommap
	END
