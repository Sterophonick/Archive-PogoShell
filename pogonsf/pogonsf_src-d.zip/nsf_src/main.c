#include <stdio.h>
#include <string.h>
#include "gba.h"
#include "minilzo.107/minilzo.h"

extern u32 hflags;	//from cart.s
extern u32 joycfg;	//from io.s
extern u32 font;
extern u32 fontpal;
extern u8 Image$$RO$$Limit;
extern volatile u32 agb_vbl;	//6502.s

//asm calls
void loadcart(int,int);	//from cart.s
void run(int);
void ppu_init(void);
void resetSIO(u32);//io.s
void nsfreset(void);
void nsfinit(int);
void nsfplay(void);

void doReset(void);

const unsigned __fp_status_arm=0x40070000;
u8 *textstart;//where rom descriptions reside (initialized by boot.s)
#define SONGS *(u8*)0x201d006

void C_entry() {
	int lastsong,waitdone;
	int joypad,lastjoy,key;
	int currentsong, count;
	
	currentsong=count=waitdone=0;

	textstart=(*(u8**)0x0203FBFC);
	ppu_init();
	lzo_init();

	loadcart(0,0);

	lastsong=(SONGS)-1;
	nsfreset();
	nsfinit(currentsong);

	lastjoy=joypad=REG_P1^0x3ff;
	while(1) {
		count++;
		joypad=REG_P1^0x3ff;
		lastjoy=lastjoy^joypad;
		key=lastjoy&joypad;
		lastjoy=joypad;

		if(key&RIGHT) {
			if(currentsong<lastsong)
				currentsong++;
			else
				currentsong=0;
			nsfinit(currentsong);
		}
		if(key&LEFT) {
			if(currentsong)
				currentsong--;
			else
				currentsong=lastsong;
			nsfinit(currentsong);
		}
		if(joypad&(START|B_BTN)) {
		  waitdone=1;
		} else if (waitdone) {
	          REG_SGCNT0_L=0;         //stop sound (GB)
	          REG_TM0CNT=0;           //stop sound (directsound)
		  doReset();
		}
		if(joypad&UP) {
			nsfplay();
		}
		if(!(joypad&DOWN) || (count&1))
			nsfplay();
		while(!agb_vbl);
		agb_vbl=0;
	}
}

u8* findrom() {
#define HEAP_START (&Image$$RO$$Limit)

         lzo_uint size;
	char *s=(char*)0x203fc08;
	do s++; while(*s);
	do s++; while(*s);
         if (s[-2] == 'z' || s[-2] == 'Z') {
           size = *(u32*)0x0203FBF8;
	  lzo1x_decompress(textstart,size,
                            (u8*) HEAP_START,
                            &size,NULL);
           return (u8*) HEAP_START;
         } else {
	   return textstart;
         }
}
