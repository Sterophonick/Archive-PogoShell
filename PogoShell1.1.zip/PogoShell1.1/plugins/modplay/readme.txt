
This examples does not use pogo - it's a simple
modplayer (using libafm) that demonstrates how
to read arguments from pogo without the library.

put it as ./plugins/mod.bin in your filesystem
and it will be executed when you click on a mod-
file.

It also demonstrates how to make a proper soft-
reset (resets the cart-start to beginning of the
cart and does a BIOS soft-reset).

// Sasq
