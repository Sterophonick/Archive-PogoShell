#!/usr/bin/python

import os, sys, struct
from sys import argv
from stat import *

def readfile(name):
	try:
		fd = open(name, "rb")
		contents = fd.read()
		fd.close()
	except IOError:
		print "Error reading", name
		sys.exit(1)
	return contents

def writefile(name, contents):
	try:
		fd = open(name, "wb")
		fd.write(contents)
		fd.close()
	except IOError:
		print "Error writing", name
		sys.exit(1)

if __name__ == "__main__":
	EZFLA_UP="ezfla_up.bin"

	ezflaup = readfile(EZFLA_UP)

	offset = 0x40000

	while ezflaup[offset] != "\x00":
		name = ""
		idx = 0
		while ezflaup[offset+idx] != "\x00":
			name += ezflaup[offset+idx]
			idx += 1
		size = struct.unpack("<I", ezflaup[offset+264:offset+264+4])[0]
		if size > 0:
			r = name.rfind("\\")
			if r != -1:
				name = name[r+1:]
			start = offset+264+8
			end = (start+size+3)&(~3)
			contents = ezflaup[offset+264+8:end]
			contents = contents[0:size]
			writefile(name, contents) 
		offset += 264 + 8 + ((size+3)&(~3))
