
import sys, os, re
from sys import argv
from struct import pack, unpack

def readfile(name):
	fd = open(name, "rb")
	if not fd:
		print "Error reading", name
	contents = fd.read()
	fd.close()
	return contents

def toPixel(red, green, blue, transparent = 0):
	transparent <<= 15
	red = ((red>>3)&31)<<10
	green = ((green>>3)&31)<<5
	blue = ((blue>>3)&31)<<0
	return pack("<h", transparent + red + green + blue)

if __name__ == "__main__":
	if len(argv) == 3:
		contents = readfile(argv[1])
		fd = open(argv[2], "wb")
		fd.write("BM")
		mo = re.compile("P6\s([^\d][^\n]*\n)?(\d+)\s(\d+)\s(\d+)\s(.*)").match(contents)
		gmo = mo.groups()
		width = int(gmo[-4])
		height = int(gmo[-3])
		maxcolors = int(gmo[-2])
		data = gmo[-1]
		if maxcolors < 256:
			depth = 16
		else:
			print "Error: Unsupported file type."
			sys.exit(1)
		fd.write(pack("<3h", depth, width, height))
		tred, tgreen, tblue = ord(data[0]), ord(data[1]), ord(data[2])
		for y in range(height):
			for x in range(width):
				red = ord(data[y*width*3+x*3])
				green = ord(data[y*width*3+x*3+1])
				blue = ord(data[y*width*3+x*3+2])
				if tred == red and tgreen == green and tblue == blue:
					pixel = toPixel(red, green, blue, 1)
				else:
					pixel = toPixel(red, green, blue)
				fd.write(pixel)
		fd.close()
	else:
		print "Usage: %s file.bm file.ppm" % argv[0]
