
This is the vboy.exe and SDL.dll files from Pogoshell v2.0b3.  They were
modified by Sasq to support flash cart emulation, for testing purposes.
Feel free to use them.

--Kuwanger
