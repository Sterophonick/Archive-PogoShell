#ifndef SCREEN_H
#define SCREEN_H

enum {SCREEN_WIDTH, SCREEN_HEIGHT};

enum {SCREENP_WIDTH, SCREENP_HEIGHT};

#define SC_SETPAL 5
#define SC_SETMODE 6

#endif
