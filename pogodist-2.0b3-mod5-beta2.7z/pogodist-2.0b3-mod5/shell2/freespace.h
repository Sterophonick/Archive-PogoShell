
#include "filesys.h"
#define FREEPTR ((0x02000000+(sizeof(DirList)+10+32)*MAX_FILE_COUNT))
