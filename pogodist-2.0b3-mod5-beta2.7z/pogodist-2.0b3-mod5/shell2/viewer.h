
extern int jpegHeight;
extern int jpegWidth;

